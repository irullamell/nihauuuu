//© AkiraaBot 2023-2024
// • Credits : wa.me/6287869975929 [ Bang syaii ]
// • Owner: 6283831945469,6287869975929

/*
• untuk siapa pun yang ketahuan menjual script ini tanpa sepengetahuan developer mohon untuk dilaporkan !
*/

//© AkiraaBot 2023-2024
// • Credits : wa.me/6287869975929 [ Bang syaii ]
// • Owner: 6283831945469,6287869975929

/*
• untuk siapa pun yang ketahuan menjual script ini tanpa sepengetahuan developer mohon untuk dilaporkan !
*/

let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `*• Example :* ${usedPrefix + command} *[question]*`;
  m.reply(wait);
  try {
    let response = await Scraper["Ai"].blackboxAIChat(text);
    m.reply(response);
  } catch (e) {
    throw eror;
  }
};
handler.help = ["bb", "blackbox", "kotakhitam", "blekbok"].map(
  (a) => a + " *[question]*",
);
handler.tags = ["ai"];
handler.command = ["bb", "blackbox", "kotakhitam", "blekbok"];

module.exports = handler;
