const Gemini = new Scraper["Ai"].Gemini();
module.exports = {
  help: ["gemini"].map((a) => a + " *[query]*"), //nama fitur kami
  command: ["gemini"], //untuk eksekusi fitur nya
  tags: ["ai"], //fitur kamu termasuk kategori apa?
  code: async (m, { conn, usedPrefix, command, text }) => {
    if (!text)
      throw `*• Example :* ${usedPrefix + command} Hello My name is Gemini`;
    m.reply(wait);
    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype;
    if (/image/.test(mime)) {
      let url = await Uploader.catbox(await q.download());
      let data = await Gemini.image(url, text);
      m.reply(`*[ GEMINI ]*\n${data}`);
    } else {
      let data = await Gemini.conversation(text);
      m.reply(`*[ GEMINI ]*\n${data}`);
    }
  },
};
