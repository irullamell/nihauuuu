//© AkiraaBot 2023-2024
// • Credits : wa.me/6287869975929 [ Bang syaii ]
// • Owner: 6287869975929,6283831945469

/*
• untuk siapa pun yang ketahuan menjual script ini tanpa sepengetahuan developer mohon untuk dilaporkan !
*/

const Ondoku = new Scraper["Ai"].Ondoku3();

module.exports = {
  help: ["ondoku"].map((a) => a + " *[send media/input text]*"),
  tags: ["ai"],
  command: ["ondoku"],
  code: async (
    m,
    {
      conn,
      usedPrefix,
      command,
      text,
      isOwner,
      isAdmin,
      isBotAdmin,
      isPrems,
      chatUpdate,
    },
  ) => {
    let q = m.quoted ? m.quoted : m;
    let mime = q.mimetype || "";
    if (mime) {
      m.reply(wait);
      let data = await Ondoku.imageToSpeech(await q.download());
      conn.sendFile(m.chat, data.url, null, data.url, m);
    } else {
      if (!text) throw `*• Example :* ${usedPrefix + command} *[input text]*`;
      m.reply(wait);
      let data = await Ondoku.textToSpeech(text);
      conn.sendFile(m.chat, data.url, null, data.url, m);
    }
  },
};
