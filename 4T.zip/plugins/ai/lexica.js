//© AkiraaBot 2023-2024
// • Credits : wa.me/6287869975929 [ Bang syaii ]
// • Owner: 6287869975929,6283831945469

/*
• untuk siapa pun yang ketahuan menjual script ini tanpa sepengetahuan developer mohon untuk dilaporkan !
*/

module.exports = {
  help: ["lexica"].map((a) => a + " *[query]*"),
  tags: ["ai"],
  command: ["lexica"],
  code: async (
    m,
    {
      conn,
      usedPrefix,
      command,
      text,
      isOwner,
      isAdmin,
      isBotAdmin,
      isPrems,
      chatUpdate,
    },
  ) => {
    if (!text) throw `*• Example :* ${usedPrefix + command} *[query]*`;
    m.reply(wait);
    let result = await Func.fetchJson(
      "https://lexica.art/api/v1/search?q=" + text,
    );
    let data = Func.random(result.images);
    let cap = `*[ LEXICA - ART ]*
*• Id :* ${data.id}
*• Prompt :* ${data.prompt}
*• Ratio :* ${data.width} x ${data.height}
*• Seed :* ${data.seed}
*• Grid :* ${data.grid}
*• Model :* ${data.model}
*• Gallery :* ${data.gallery}`;
    m.reply(cap, data.src);
  },
};
