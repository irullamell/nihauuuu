//© AkiraaBot 2023-2024
// • Credits : wa.me/6287869975929 [ Bang syaii ]
// • Owner: 6285731251154

/*
• untuk siapa pun yang ketahuan menjual script ini tanpa sepengetahuan developer mohon untuk dilaporkan !
*/

async function gptlogic(text) {
    try {
        const response = await axios.post(
            "https://ragbot-starter.vercel.app/api/chat", {
                messages: [{
                        role: "assistant",
                        content: "kamu berperan sebagai Ai serbaguna bernama Fiesta AI, kamu di ciptakan oleh irull",
                    },
                    {
                        role: "user",
                        content: text,
                    },
                ],
                useRag: true,
                llm: "gpt-4o",
                similarityMetric: "cosine",
            },
        );

        return response.data;
    } catch (error) {
        console.error(error);
        return error;
    }
}

let handler = async (m, {
    conn,
    args,
    usedPrefix,
    command
}) => {
    let text;

    if (args.length >= 1) {
        text = args.join(" ");
    } else if (m.quoted && m.quoted.text) {
        text = m.quoted.text;
    } else {
        return m.reply(`*• Example :* ${usedPrefix + command} *[question]*`);
    }
    m.reply(wait);
    try {
        let bard = await gptlogic(text);
        m.reply(bard);
    } catch (error) {
        console.error(error);
        throw error;
    }
};

handler.help = ["ai", "openai", "chagpt"].map((a) => a + " *[question]*");
handler.tags = ["ai"];
handler.command = ["ai", "openai", "chatgpt"];

module.exports = handler;