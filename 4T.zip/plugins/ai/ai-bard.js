//© AkiraaBot 2023-2024
// • Credits : wa.me/6287869975929 [ Bang syaii ]
// • Owner: 6285731251154

/*
• untuk siapa pun yang ketahuan menjual script ini tanpa sepengetahuan developer mohon untuk dilaporkan !
*/

const Gemini = new Scraper["Ai"].Gemini();
module.exports = {
    help: ["bard"].map((a) => a + " *[query]*"), //nama fitur kami
    command: ["bard"], //untuk eksekusi fitur nya
    tags: ["ai"], //fitur kamu termasuk kategori apa?
    code: async (m, {
        conn,
        usedPrefix,
        command,
        text
    }) => {
        if (!text)
            throw `*• Example :* ${usedPrefix + command} Hello My name is Bard`;
        m.reply(wait);
        let q = m.quoted ? m.quoted : m;
        let mime = (q.msg || q).mimetype;
        if (/image/.test(mime)) {
            let url = await Uploader.catbox(await q.download());
            let data = await Gemini.image(url, text);
            m.reply(`*[ BARD AI ]*\n${data}`);
        } else {
            let data = await Gemini.conversation(text);
            m.reply(`*[ BARD AI ]*\n${data}`);
        }
    },
};