module.exports = {
  help: ["txt2img"].map((a) => a + " *[prompt]*"),
  tags: ["ai"],
  command: ["txt2img"],
  code: async (
    m,
    {
      conn,
      usedPrefix,
      command,
      text,
      isOwner,
      isAdmin,
      isBotAdmin,
      isPrems,
      chatUpdate,
    },
  ) => {
    let Prodia = await Scraper["Ai"].Prodia(prodia.key);
    let database = db.data.txt2img ? db.data.txt2img : {};
    if (!text)
      throw `*• Example :* ${usedPrefix + command} *[prompt]*

*Custom generated*
--model *[change model]*
--sampler *[change sampler]*`;
    let keyword = text.split(" ")[0];
    let data = text.slice(keyword.length + 1);
    if (!database[m.sender]) {
      database[m.sender] = {
        model: "mechamix_v10.safetensors [ee685731]",
        sampler: "DPM++ 2M Karras",
      };
    }
    if (keyword === "--model") {
      let model = await Prodia.getModels();
      if (!data)
        throw `*Enter Model* type *1 ~> ${model.length}* to change the model
${model.map((a, i) => `*${i + 1}.* ${a.split(".")[0]}`).join("\n")}`;
      if (isNaN(data))
        throw `*Enter Model* type *1 ~> ${model.length}* to change the model
${model.map((a, i) => `*${i + 1}.* ${a.split(".")[0]}`).join("\n")}`;
      if (parseInt(data) > model.length)
        throw `*Enter Model* type *1 ~> ${model.length}* to change the model
${model.map((a, i) => `*${i + 1}.* ${a.split(".")[0]}`).join("\n")}`;
      database[m.sender].model = model[data - 1];
      m.reply(
        `Successfully changed model to *${model[data - 1].split(".")[0]}*`,
      );
    } else if (keyword === "--sampler") {
      let model = await Prodia.getSamplers();
      if (!data)
        throw `*Enter Sampler* type *1 ~> ${model.length}* to change the sampler
${model.map((a, i) => `*${i + 1}.* ${a}`).join("\n")}`;
      if (isNaN(data))
        throw `*Enter Sampler* type *1 ~> ${model.length}* to change the sampler
${model.map((a, i) => `*${i + 1}.* ${a}`).join("\n")}`;
      if (parseInt(data) > model.length)
        throw `*Enter Sampler* type *1 ~> ${model.length}* to change the sampler
${model.map((a, i) => `*${i + 1}.* ${a}`).join("\n")}`;
      database[m.sender].sampler = model[data - 1];
      m.reply(`Successfully changed sampler to *${model[data - 1]}*`);
    } else {
      m.reply(wait);
      let json = {
        ...database[m.sender],
        prompt: text,
        negative_prompt: "blur, nsfw, bad quality, bad anatomy, black",
        style_preset: "anime",
        upscale: true,
        steps: 20,
        seed: Math.floor(Math.random() * 200000000),
        cfg_scale: 7,
        width: 400,
        height: 800,
      };
      let hasil = await Prodia.generateImage(json);
      if (hasil.status === "queued") {
        hasil = await Prodia.wait(hasil);
        await conn.sendMessage(
          m.chat,
          {
            image: {
              url: hasil.imageUrl,
            },
            caption: `Successfully generated image
*• Prompt :* ${json.prompt}
*• Model :* ${json.model || "Not using"}
*• Seed :* ${json.seed}
*• Sampler :* ${json.sampler || "Not using"}`,
          },
          {
            quoted: m,
          },
        );
      }
    }
  },
};
