
let handler = async (m, { conn, text, usedPrefix, command }) => {
    conn.anime = conn.anime ? conn.anime : {};
    if (!text) {
        throw `*[ ANIME EXAMPLE ]*
> *• Example :* ${usedPrefix + command} search *[title anime]*
> *• Example :* ${usedPrefix + command} detail *[slug_id]*
> *• Example :* ${usedPrefix + command} stream *[slug_id]*
> *• Example :* ${usedPrefix + command} latest`;
    }
    
    const keyword = text.split(" ")[0];
    const data = text.slice(keyword.length + 1).trim();
    
    if (keyword.toLowerCase() === "search") {
        if (!data) {
            throw `*• Example :* ${usedPrefix + command} search *[title anime]*`;
        }
        
        let response = await Func.fetchJson(`https://api.apigratis.site/anime/search?query=${data}`);
        let results = response.result.results;
        
        let cap = `*[ ANIME SEARCH ]*
${results.map(a => `*• Title :* ${a.title}
*• Slug :* ${a.slug}
*• Cover :* ${a.cover}`).join("\n\n")}`;
        
        let array = results.map((i, index) => ({
            rows: [{
                title: `${index + 1}. Get detail Anime`,
                body: `• Title : ${i.title}`,
                command: `${usedPrefix}anime detail ${i.slug}`
            }]
        }));
        
        conn.sendList(m.chat, "Detail Anime", array, fkontak, { body: cap, url: results[0].cover });
        conn.anime[m.sender] = results;
    } else if (keyword.toLowerCase() === "detail") {
        if (!data) {
            throw `*• Example :* ${usedPrefix + command} detail *[slug_id]*`;
        }
        
        m.reply(wait);
        
        let response = await Func.fetchJson(`https://api.apigratis.site/anime/series?slug=${data}`);
        let result = response.result;
        
        let cap = `*[ ANIME DETAIL ]*
*• Title :* ${result.title}
*• Total Episodes :* ${result.total_episode}
${Object.entries(result.info).map(([key, value]) => `- *${key} :* ${typeof value === 'object' ? value.join(", ") : value}`).join("\n")}
        
${result.synopsis}`;
        
        let array = result.episodes.map((episode, index) => ({
            rows: [{
                title: `${index + 1}. Episode ${episode.episode}`,
                body: `• Release : ${episode.date}`,
                command: `${usedPrefix}anime stream ${episode.slug}`
            }]
        }));
        
        conn.sendList(m.chat, "Stream Anime", array, fkontak, { body: cap, url: result.cover });
    } else {
        throw `*[ UNKNOWN COMMAND ]*
> Please use one of the examples provided`;
    }
};

handler.help = ["anime"].map(a => `${a} *[animekita info]*`);
handler.tags = ["anime"];
handler.command = ["anime"];

module.exports = handler;