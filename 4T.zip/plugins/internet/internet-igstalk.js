//© AkiraaBot 2023-2024
// • Credits : wa.me/6287869975929 [ Bang syaii ]
// • Owner: 6287869975929,6283831945469

/*
• untuk siapa pun yang ketahuan menjual script ini tanpa sepengetahuan developer mohon untuk dilaporkan !
*/

module.exports = {
  help: ["igstalk"].map((a) => a + " *[username]*"),
  tags: ["internet"],
  command: ["igstalk"],
  code: async (
    m,
    {
      conn,
      usedPrefix,
      command,
      text,
      isOwner,
      isAdmin,
      isBotAdmin,
      isPrems,
      chatUpdate,
    },
  ) => {
    if (!text) throw `*• Example :* ${usedPrefix + command} *[username]*`;
    m.reply(wait);
    let req = await axios.get(
      `https://akhirpetang.vercel.app/api/ig?username=${encodeURIComponent(text)}`,
      {
        headers: {
          Authorization: "Bearer akhirpetang-09853773678853385327Ab63",
        },
      },
    );
    let info = req.data;
    let cap = `*[ IG - STALK ]*
*• Username :* ${info.username}
*• FullName :* ${info.nama_lengkap}
*• Followers :* ${info.jumlah_pengikut}
*• Following :* ${info.jumlah_diikuti}
*• Total Post :* ${info.jumlah_postingan}

${info.biography}`;
    await conn.sendUrl(
      m.chat,
      [["Url Account", "https://www.instagram.com/@" + info.username]],
      m,
      {
        body: cap,
        url: info.foto_profil,
      },
    );
  },
};
