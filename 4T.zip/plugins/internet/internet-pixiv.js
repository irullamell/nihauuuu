//© AkiraaBot 2023-2024
// • Credits : wa.me/6287869975929 [ Bang syaii ]
// • Owner: 6287869975929,6283831945469,6283823549074

/*
• untuk siapa pun yang ketahuan menjual script ini tanpa sepengetahuan developer mohon untuk dilaporkan !
*/

let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `*• Example :* ${usedPrefix + command} *[query]*`;
  m.reply(wait);
  try {
    let search = await (
      await Func.fetchJson(
        `https://wow-balxzzy.vercel.app/api/pixiv?query=${text}`,
      )
    ).result;
    let random = await Func.random(search);
    let cap = `*• Caption :* ${random.title}
*• Tags :* ${random.tags.map((a) => a.name).join(", ")}`;
    conn.sendButton(
      m.chat,
      [["NEXT IMAGE", `${usedPrefix + command} ${text}`]],
      m,
      {
        body: cap,
        url: random.urls.regular,
      },
    );
  } catch (e) {
    throw e;
  }
};
handler.help = ["pixiv"].map((a) => a + " *[query]*");
handler.tags = ["internet"];
handler.command = ["pixiv"];

module.exports = handler;
