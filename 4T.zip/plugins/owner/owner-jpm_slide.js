let handler = async (m, { conn, text, participants, usedPrefix, command }) => {
  let q = m.quoted ? m.quoted : m;
  let mime = (q.msg || q).mimetype || "";
  let groups = Object.keys(store.groupMetadata);
  conn.reply(m.chat, `Sending Broadcast to Group : [ ${groups.length} ]`, m);
  for (let id of groups) {
    let participantIds = participants.map((a) => a.id);
    await conn.sendCarousel(
      id,
      [
        [
          `*± H O S T I N G - B O T*
	
* Ram : 5GB Disk : 50GB = 6.000/BULAN
* Ram : 6GB Disk : 60GB = 7.000/BULAN
* Ram : 7GB Disk : 70GB = 8.000/BULAN
* Ram : 8GB Disk : 80GB = 9.000/BULAN
* Ram : 9GB Disk : 90GB = 10.000/BULAN
	
	*Masih nego ? Benefit Hangus !!*
	
	*• Benefit :*
- Server Fresh anti lemot ✓
- Server Uptime 24 jam ✓
- Full garansi 30D ✓
* Script  terjaga ✓
- No Boros Kouta/Storage ✓
- Simple ✓
	
	*• Payment :*
* DANA 	
* OVO
* GOPAY 
* QRIS`,
          "® Order panel click button dibawah",
          "https://files.catbox.moe/tzdnj1.jpg",
          [],
          null,
          [
            [
              "🛒 ORDER PANEL",
              "https://wa.me/6287869975929?text=bang+beli-panel",
            ],
          ],
        ],
        [
          `*± S E L L - S C R I P T]*
* *Name :* AkiraaBot
* *Type :* plugins ( Cjs )
* *Features :* 450+
* *Example bot :* [ https://chat.whatsapp.com/DQYx0cW0XV33nJjobm7Sk9 ]
* *Total Buyer :* [ https;//chat.whatsapp.com/BABqCbjaGAJ8COukvUvD6M ]
* *Normal Price :* 50.0000
* *Discount Price :* 40.000
	
	*Masih Nego ? Benefit Hangus !!*
	
* Sc no enc 100%
* support qr/pairing 
* Support button
* Size dibawah 5Mb
* 80% Scrape 
* Support Payment getaway 
	
	*• Benefit :*
* Free Update always Time !
* Free Apikey Premium 
* Free hosting bot wa
	
	*• Payment :*
* DANA
* OVO 
* GOPAY
* QRIS`,
          "",
          thumb,
          [],
          null,
          [
            [
              "🛒 ORDER SCRIPT",
              "https://wa.me/6287869975929?text=bang+beli+sc",
            ],
          ],
        ],
        [
          `*± S E W A - B O T*
	
	*• Price :*
* 1.000/hari
* 7.000/Minggu
* 30.000/Bulan
* 360.000/tahun
	
	*• Note :*
* Khusus 1 group/order
* Bor akan keluar jika masa expired habis
* Langgar aturan bot ?, Bot aja keluar
	
	*• Fitur :*
* Welcome message 
* Leave message
* Card intro
* Game menu 
* Rpg Menu
* Anti link Group 
* Close/open Group
* Hidetag 
* Tagall
	
	*• Payment :*
	* DANA
	* OVO
	* GOPAY`,
          "",
          thumb,
          [],
          null,
          [
            [
              "🛒 ORDER SEWABOT",
              "https://wa.me/6287869975929?text=bang+mau+sewabot",
            ],
          ],
        ],
      ],
      null,
      {
        body: text
          ? text
          : `*Syaii Store menyediakan ⤵️*
	_Kami Menyediakan beberapa produk digital seperti :_
	
* Panel server private
* Reseller panel private 
* Jasa install panel & wings
* Jasa install thema panel 
* Jasa Fix sc botwa
* Jasa Recode botwa
* Jasa add fitur botwa
* Jasa ubah sc qr ke pairing
* Sc bot WhatsApp Premium 
* Nokos WhatsApp +62`,
      },
    );
    await conn.delay(1000);
  }
};

handler.help = ["jpm_slide"].map((v) => v + " *[jpm with slide button]*");
handler.tags = ["owner"];
handler.command = ["jpm_slide"];
handler.owner = true;
module.exports = handler;

const more = String.fromCharCode(8206);
const readMore = more.repeat(4001);

const randomID = (length) =>
  require("crypto")
    .randomBytes(Math.ceil(length * 0.5))
    .toString("hex")
    .slice(0, length);
