//© Fiestaa
// • Owner: 6285646584823

/*
• untuk siapa pun yang ketahuan menjual script ini tanpa sepengetahuan developer mohon untuk dilaporkan !
*/

let handler = async (m, {
    conn,
    text
}) => {
    let chats = Object.keys(await conn.chats)
    conn.reply(m.chat, `_Broadcasting ke ${chats.length} chat_`, m)

    for (let id of chats) {
        await new Promise(resolve => setTimeout(resolve, 3000)) // Simpler sleep
        conn.relayMessage(id, {
            extendedTextMessage: {
                text: text.trim(),
                contextInfo: {
                    externalAdReply: {
                        title: wm,
                        mediaType: 1,
                        thumbnailUrl: 'https://telegra.ph/file/aa76cce9a61dc6f91f55a.jpg'
                    }
                },
                mentions: [m.sender]
            }
        }, {})
    }
    m.reply('Broadcast selesai')
}

handler.help = ['broadcast', 'bc'].map(v => v + ' <teks>')
handler.tags = ['owner']
handler.command = /^(broadcast|bc)$/i
handler.owner = true

module.exports = handler