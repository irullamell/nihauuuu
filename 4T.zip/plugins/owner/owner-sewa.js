const linkRegex = /chat.whatsapp.com\/([0-9A-Za-z]{20,24})/i;

let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `*• Example :* ${usedPrefix + command} *[link,duration]*`;
  let [Target, duration] = text.split(",");
  if (!Target) return;
  if (!Func.isUrl(Target)) throw "*[!] Input Link Group*";
  let [_, code] = Target.match(linkRegex) || [];
  let id = await conn.groupAcceptInvite(code);
  const user = db.data.chats[id];
  if (duration) {
    let milidetikDalamHari = 24 * 60 * 60 * 1000;
    let angka = duration;
    let hasil = angka * milidetikDalamHari;
    let { key } = await conn.sendMessage(
      m.chat,
      { text: "*[ VERIFYING DATA... ]*" },
      { quoted: m },
    );
    user.sewa = true;
    user.expired = hasil;
    await conn.sendMessage(
      m.chat,
      {
        text: `*[ ✅ VERIFICATION SUCCESS ]*
*• Sewabot:* ${user.sewa ? "✅" : "❎"}
*• Expired:* ${duration} *Day* *[${Func.toDate(user.expired)}]*`,
        edit: key,
      },
      { quoted: m },
    );
    await conn.sendMessage(
      id,
      {
        text: `Hi Semua nya saya adalah *YoriBot*, saya akan menjadi asisten group ini selama ${Func.toDate(user.expired)}, silahkan nikmati fitur yang audah kami sediakan dan jangan salahgunakan fitur bot, tetep baca *.rules* kami sebelum nenggunakan bot ini
        
Ketik *.menu* untuk melihat fitur bot`,
      },
      { quoted: null },
    );
  } else {
    let { key } = await conn.sendMessage(
      m.chat,
      { text: "*[ VERIFYING DATA... ]*" },
      { quoted: m },
    );
    user.sewa = true;
    user.expired = "PERMANENT";
    await conn.sendMessage(
      m.chat,
      {
        text: `*[ ✅ VERIFICATION SUCCESS ]*
*• Sewabot:* ${user.sewa ? "✅" : "❎"}
*• Expired:* ${duration} *Day* *[${Func.toDate(user.expired)}]*`,
        edit: key,
      },
      { quoted: m },
    );
    await conn.sendMessage(
      id,
      {
        text: `Hi Semua nya saya adalah *YoriBot*, saya akan menjadi asisten group ini selama PERMANENT, silahkan nikmati fitur yang audah kami sediakan dan jangan salahgunakan fitur bot, tetep baca *.rules* kami sebelum nenggunakan bot ini
        
Ketik *.menu* untuk melihat fitur bot`,
      },
      { quoted: null },
    );
  }
};
handler.help = ["sewa"].map((a) => a + " *[link,duration]*");
handler.tags = ["owner"];
handler.command = ["sewa"];
handler.owner = true;

module.exports = handler;

function no(number) {
  return number.replace(/\s/g, "").replace(/([@+-])/g, "");
}
