//© Fiestaa
// • Owner: 6285731251154

/*
• untuk siapa pun yang ketahuan menjual script ini tanpa sepengetahuan developer mohon untuk dilaporkan !
*/

let fs = require("fs");
let {
    js
} = require("js-beautify");
let handler = async (m, {
    text,
    usedPrefix,
    command
}) => {
    if (!text) throw `*• Example:* ${usedPrefix + command} *[filename]*`;

    if (command === "sf") {
        if (!m.quoted) throw `*[ ! ] Reply Your Progress Code*`;
        let path = `plugins/${text}.js`;
        await fs.writeFileSync(
            path,
            await js(`//© Fiestaa
// • Owner: ${owner}

/*
• untuk siapa pun yang ketahuan menjual script ini tanpa sepengetahuan developer mohon untuk dilaporkan !
*/\n\n${m.quoted.text}`),
        );
        let key = await conn.sendMessage(
            m.chat, {
                text: "*Menyimpan kode 🏜️*",
            }, {
                quoted: m,
            },
        );
        await conn.sendMessage(
            m.chat, {
                text: `*[ SUKSES DALAM MENYIMPAN KODE ]*\n\n\`\`\`${m.quoted.text}\`\`\``,
                edit: key.key,
            }, {
                quored: m,
            },
        );
    } else if (command === "df") {
        let path = `plugins/${text}.js`;
        let key = await conn.sendMessage(
            m.chat, {
                text: "*[ DELETE FILE... ]*",
            }, {
                quoted: m,
            },
        );
        if (!fs.existsSync(path))
            return conn.sendMessage(
                m.chat, {
                    text: `*[ FILE TIDAK DITEMUKAN ]*`,
                    edit: key.key,
                }, {
                    quored: m,
                },
            );
        fs.unlinkSync(path);
        await conn.sendMessage(
            m.chat, {
                text: `*[ FILE BERHASIL DI HAPUS ]*`,
                edit: key.key,
            }, {
                quored: m,
            },
        );
    }
};
handler.help = ["sf", "df"].map((v) => v + " *[reply code/filename]*");
handler.tags = ["owner"];
handler.command = /^(sf|df)$/i;
handler.rowner = true;
module.exports = handler;