//© AkiraaBot 2023-2024
// • Credits : wa.me/6287869975929 [ Bang syaii ]
// • Owner: 6285731251154

/*
• untuk siapa pun yang ketahuan menjual script ini tanpa sepengetahuan developer mohon untuk dilaporkan !
*/

const handler = async (m, {
    conn
}) => {
    try {
        // Menghapus chat grup
        const chatIdsToDeleteGroup = Object.values(conn.chats)
            .filter(item => /@g\.us$/.test(item.id))
            .map(item => item.id);

        const deletedGroupCount = chatIdsToDeleteGroup.length;

        for (const id of chatIdsToDeleteGroup) {
            await conn.chatModify({
                delete: true,
                lastMessages: [{
                    key: m.key,
                    messageTimestamp: m.messageTimestamp
                }]
            }, id);
        }

        // Menghapus chat pribadi
        const chatIdsToDeletePrivate = Object.values(conn.chats)
            .filter(item => /@s.whatsapp\.net$/.test(item.id))
            .map(item => item.id);

        const deletedPrivateCount = chatIdsToDeletePrivate.length;

        for (const id of chatIdsToDeletePrivate) {
            await conn.chatModify({
                delete: true,
                lastMessages: [{
                    key: m.key,
                    messageTimestamp: m.messageTimestamp
                }]
            }, id);
        }

        // Menggabungkan hasil
        const combinedResult = `🗑️ *Deleted Group Chats:* ${deletedGroupCount}\n🗑️ *Deleted Private Chats:* ${deletedPrivateCount}`;
        await conn.reply(m.chat, combinedResult, m);

    } catch (error) {
        console.error(error);
        await conn.reply(m.chat, "Terjadi kesalahan dalam menghapus chat.", m);
    }
};

handler.help = ["clearchat"];
handler.tags = ["owner"];
handler.owner = true;
handler.command = /^(clearcha?t)$/i;

module.exports = handler;