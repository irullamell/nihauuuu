//© AkiraaBot 2023-2024
// • Credits : wa.me/6287869975929 [ Bang syaii ]
// • Owner: 6285731251154

/*
• untuk siapa pun yang ketahuan menjual script ini tanpa sepengetahuan developer mohon untuk dilaporkan !
*/

let handler = async (m, {
    conn,
    text,
    usedPrefix,
    command
}) => {
    if (!text) throw `*• Example :* ${usedPrefix + command} *[on/off]*`;
    let chat = db.data.chats[m.chat];
    if (text === "on") {
        chat.mute = true;
        m.reply("Success Trun On *[ Mute Mode ]*");
    } else if (text === "off") {
        chat.mute = false;
        m.reply("Success Trun Off *[ Mute Mode ]*");
    } else throw `*• Example :* ${usedPrefix + command} *[on/off]*`;
};
handler.help = ["o-mute"].map((a) => a + "*[on/off]*");
handler.tags = ["owner"];
handler.command = ["o-mute"];
handler.group = true;
handler.owner = true;

module.exports = handler;