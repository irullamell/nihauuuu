//© Fiestaa
// • Owner: 6285646584823

/*
• untuk siapa pun yang ketahuan menjual script ini tanpa sepengetahuan developer mohon untuk dilaporkan !
*/

const fs = require('fs/promises'); // Keep this one
const path = require('path');
const fsSync = require('fs'); // You can keep this if you need the synchronous version for specific tasks

const FOLDER_PATH = path.resolve('../database');
const FILE_PATH = path.join(FOLDER_PATH, 'confes.json');
const LOG_PATH = path.resolve('../logs/activity.log');

// Membuat folder dan file jika belum ada
const ensureDatabaseExists = async () => {
    try {
        // Cek apakah folder sudah ada, jika belum buat folder
        if (!fsSync.existsSync(FOLDER_PATH)) {
            await fs.mkdir(FOLDER_PATH, {
                recursive: true
            });
            console.log(`Folder ${FOLDER_PATH} berhasil dibuat.`);
        }

        // Cek apakah file sudah ada, jika belum buat file dengan konten default
        if (!fsSync.existsSync(FILE_PATH)) {
            await fs.writeFile(FILE_PATH, JSON.stringify({}, null, 2));
            console.log(`File ${FILE_PATH} berhasil dibuat.`);
        }

    } catch (error) {
        console.error(`Gagal membuat folder atau file: ${error.message}`);
    }
};

// Membaca data dari file JSON
const readConfesData = async () => {
    await ensureDatabaseExists(); // Memastikan file dan folder sudah ada
    try {
        const data = await fs.readFile(FILE_PATH, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        return {}; // Jika file tidak ada atau error, kembalikan objek kosong
    }
};

// Menulis data ke file JSON
const writeConfesData = async (data) => {
    await ensureDatabaseExists(); // Memastikan file dan folder sudah ada
    await fs.writeFile(FILE_PATH, JSON.stringify(data, null, 2));
};

// Logging aktivitas
const logActivity = async (message) => {
    const logMessage = `[${new Date().toISOString()}] ${message}\n`;

    // Cek apakah folder log ada, jika tidak buat
    const LOG_FOLDER = path.dirname(LOG_PATH);
    if (!fsSync.existsSync(LOG_FOLDER)) {
        await fs.mkdir(LOG_FOLDER, {
            recursive: true
        });
    }

    await fs.appendFile(LOG_PATH, logMessage);
};

// Normalisasi nomor telepon ke format @s.whatsapp.net
const normalizeNumber = (number) => {
    return number.includes('@s.whatsapp.net') ? number : number + '@s.whatsapp.net';
};

// Pengecekan timeout dan hapus sesi jika sudah kedaluwarsa
const checkAndCleanSessions = async (conn) => {
    const now = Date.now();
    let updated = false;

    for (let user in conn.confes) {
        const sessions = conn.confes[user];
        for (let sessionId in sessions) {
            const session = sessions[sessionId];
            if (now > session.timeout) {
                delete conn.confes[user][sessionId];
                updated = true;
            } else if (now > session.timeout - 300000 && !session.warned) { // 5 menit sebelum timeout
                try {
                    await conn.sendMessage(session.number, {
                        text: 'Sesi Confes Anda akan segera berakhir dalam 5 menit.'
                    });
                    conn.confes[user][sessionId].warned = true; // Menandai bahwa peringatan telah dikirim
                    updated = true;
                } catch (error) {
                    await logActivity(`Gagal mengirim peringatan ke ${session.number}: ${error.message}`);
                }
            }
        }

        if (Object.keys(conn.confes[user]).length === 0) {
            delete conn.confes[user]; // Hapus pengguna jika tidak ada sesi aktif
            updated = true;
        }
    }

    if (updated) {
        await writeConfesData(conn.confes);
    }
};

const fs = require('fs/promises');
const path = require('path');
const fsSync = require('fs'); // Synchronous fs module for checking file existence

const FOLDER_PATH = path.resolve('../../database');
const FILE_PATH = path.join(FOLDER_PATH, 'confes.json');
const LOG_PATH = path.resolve('../../logs/activity.log');

// Membuat folder dan file jika belum ada
const ensureDatabaseExists = async () => {
    try {
        // Cek apakah folder sudah ada, jika belum buat folder
        if (!fsSync.existsSync(FOLDER_PATH)) {
            await fs.mkdir(FOLDER_PATH, {
                recursive: true
            });
            console.log(`Folder ${FOLDER_PATH} berhasil dibuat.`);
        }

        // Cek apakah file sudah ada, jika belum buat file dengan konten default
        if (!fsSync.existsSync(FILE_PATH)) {
            await fs.writeFile(FILE_PATH, JSON.stringify({}, null, 2));
            console.log(`File ${FILE_PATH} berhasil dibuat.`);
        }

    } catch (error) {
        console.error(`Gagal membuat folder atau file: ${error.message}`);
    }
};

// Membaca data dari file JSON
const readConfesData = async () => {
    await ensureDatabaseExists(); // Memastikan file dan folder sudah ada
    try {
        const data = await fs.readFile(FILE_PATH, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        return {}; // Jika file tidak ada atau error, kembalikan objek kosong
    }
};

// Menulis data ke file JSON
const writeConfesData = async (data) => {
    await ensureDatabaseExists(); // Memastikan file dan folder sudah ada
    await fs.writeFile(FILE_PATH, JSON.stringify(data, null, 2));
};

// Logging aktivitas
const logActivity = async (message) => {
    const logMessage = `[${new Date().toISOString()}] ${message}\n`;

    // Cek apakah folder log ada, jika tidak buat
    const LOG_FOLDER = path.dirname(LOG_PATH);
    if (!fsSync.existsSync(LOG_FOLDER)) {
        await fs.mkdir(LOG_FOLDER, {
            recursive: true
        });
    }

    await fs.appendFile(LOG_PATH, logMessage);
};

// Normalisasi nomor telepon ke format @s.whatsapp.net
const normalizeNumber = (number) => {
    return number.includes('@s.whatsapp.net') ? number : number + '@s.whatsapp.net';
};

// Pengecekan timeout dan hapus sesi jika sudah kedaluwarsa
const checkAndCleanSessions = async (conn) => {
    const now = Date.now();
    let updated = false;

    for (let user in conn.confes) {
        const sessions = conn.confes[user];
        for (let sessionId in sessions) {
            const session = sessions[sessionId];
            if (now > session.timeout) {
                delete conn.confes[user][sessionId];
                updated = true;
            } else if (now > session.timeout - 300000 && !session.warned) { // 5 menit sebelum timeout
                try {
                    await conn.sendMessage(session.number, {
                        text: 'Sesi Confes Anda akan segera berakhir dalam 5 menit.'
                    });
                    conn.confes[user][sessionId].warned = true; // Menandai bahwa peringatan telah dikirim
                    updated = true;
                } catch (error) {
                    await logActivity(`Gagal mengirim peringatan ke ${session.number}: ${error.message}`);
                }
            }
        }

        if (Object.keys(conn.confes[user]).length === 0) {
            delete conn.confes[user]; // Hapus pengguna jika tidak ada sesi aktif
            updated = true;
        }
    }

    if (updated) {
        await writeConfesData(conn.confes);
    }
};

const handler = async (m, {
    conn,
    text,
    usedPrefix,
    command
}) => {
    if (m.isGroup) {
        return m.reply('Command ini tidak dapat digunakan di dalam grup. Silakan gunakan di chat pribadi.');
    }

    // Cek apakah text terdefinisi
    if (!text) {
        return m.reply('Tolong berikan teks atau perintah yang valid.');
    }

    conn.confes = await readConfesData();

    await checkAndCleanSessions(conn); // Pengecekan timeout sesi

    if (text.startsWith("start ")) {
        let cleanedNumber = text
            .replace(/^\+/, '') // Menghapus tanda +
            .replace(/[^\d]/g, ''); // Menghapus semua non-digit

        if (!cleanedNumber || cleanedNumber.length < 10) {
            return m.reply(global.try+`Tolong berikan nomor telepon yang valid.\nContoh: ${usedPrefix}${command} start +6281234567890`);
        }

        let normalizedSender = normalizeNumber(m.sender);
        let normalizedNumber = normalizeNumber(cleanedNumber);
        const sessionId = `${normalizedSender}-${Date.now()}`; // Unique session ID

        // Inisialisasi sesi untuk pengguna jika belum ada
        if (!conn.confes[normalizedSender]) {
            conn.confes[normalizedSender] = {};
        }

        conn.confes[normalizedSender][sessionId] = {
            number: normalizedNumber,
            timeout: Date.now() + 3600000,
            warned: false
        }; // Timeout 1 jam
        await writeConfesData(conn.confes);

        await logActivity(`Sesi Confes dimulai oleh ${m.sender} ke ${cleanedNumber}`);

        // Kirim notifikasi ke nomor tujuan
        try {
            await conn.sendMessage(
                normalizedNumber, // Menggunakan nomor yang dinormalisasi
                {
                    text: 'Ada yang confesin kamu nih :v\nAnda tidak bisa membalas pesan ini.'
                }
            );
        } catch (error) {
            await logActivity(`Gagal mengirim notifikasi ke ${cleanedNumber}: ${error.message}`);
            return m.reply(global.eror + `Gagal mengirim notifikasi: ${error.message}`);
        }

        return m.reply(`[ ✓ ] Sesi Confes dimulai dengan nomor ${cleanedNumber}.`);
    } else if (text.startsWith("stop")) {
        let normalizedSender = normalizeNumber(m.sender);

        if (conn.confes[normalizedSender]) {
            const sessions = conn.confes[normalizedSender];
            for (let sessionId in sessions) {
                let targetNumber = sessions[sessionId].number;

                // Hapus sesi untuk pengirim
                delete conn.confes[normalizedSender][sessionId];
                await writeConfesData(conn.confes);

                // Kirim notifikasi ke nomor tujuan bahwa sesi telah diakhiri
                try {
                    await conn.sendMessage(
                        targetNumber, // Menggunakan nomor yang dinormalisasi
                        {
                            text: 'Sesi chat Confes dengan Anda telah diakhiri.'
                        }
                    );
                } catch (error) {
                    await logActivity(`Gagal mengirim notifikasi ke ${targetNumber}: ${error.message}`);
                }
            }

            await logActivity(`Sesi Confes dihentikan oleh ${m.sender}`);
            return m.reply("[ ✓ ] Semua sesi Confes Anda telah diakhiri.");
        } else {
            return m.reply("[ ✓ ] Tidak ada sesi Confes aktif.");
        }
    }

    m.reply(global.eror + 'Format command salah. Gunakan `.confes start <nomor>` untuk memulai atau `.confes stop` untuk mengakhiri sesi.');
};

handler.before = async (m, {
    conn
}) => {
    conn.confes = await readConfesData();

    let normalizedSender = normalizeNumber(m.sender);
    await checkAndCleanSessions(conn); // Pengecekan timeout sebelum melanjutkan

    if (conn.confes[normalizedSender]) {
        const sessions = conn.confes[normalizedSender];
        for (let sessionId in sessions) {
            let targetNumber = sessions[sessionId].number;

            try {
                await conn.relayMessage(
                    targetNumber,
                    m.message, {
                        messageId: m.messageId
                    }
                );

                await conn.sendMessage(m.chat, {
                    react: {
                        text: '✔️',
                        key: m.key
                    }
                });
            } catch (error) {
                await logActivity(`Gagal meneruskan pesan dari ${m.sender} ke ${targetNumber}: ${error.message}`);
                m.reply(global.eror + `Gagal meneruskan pesan: ${error.message}`);
            }
        }
    }
};

handler.help = ['confes *[start/stop] [nomor]*'];
handler.tags = ['anonymous'];
handler.command = ["confess", "confes"]

module.exports = handler;