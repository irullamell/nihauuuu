//© AkiraaBot 2023-2024
// • Credits : wa.me/6287869975929 [ Bang syaii ]
// • Owner: 6287869975929,6283831945469

/*
• untuk siapa pun yang ketahuan menjual script ini tanpa sepengetahuan developer mohon untuk dilaporkan !
*/

module.exports = {
  help: ["font", "fancy"].map((a) => a + " *[input text]*"),
  tags: ["tools"],
  command: ["font", "fancy"],
  code: async (
    m,
    {
      conn,
      usedPrefix,
      command,
      text,
      isOwner,
      isAdmin,
      isBotAdmin,
      isPrems,
      chatUpdate,
    },
  ) => {
    if (!text) throw `*• Example :* ${usedPrefix + command} *[input text]*`;
    m.reply(wait);
    let data = Object.entries(
      (await require("../../lib/fancy-text")(text)).data,
    ).map(([a, b]) => b);
    m.reply(data.join("\n\n"));
  },
};
