//© Fiestaa
// • Owner: 6285646584823

/*
• untuk siapa pun yang ketahuan menjual script ini tanpa sepengetahuan developer mohon untuk dilaporkan !
*/

const handler = async (m, {
    conn
}) => {
    const msgs = db.data.msg || {};
    const keys = Object.keys(msgs);

    if (keys.length === 0) throw "No messages saved.";

    let categorized = {
        vn: [],
        msg: [],
        video: [],
        audio: [],
        img: [],
        stiker: [],
        gif: []
    };

    // Mengategorikan pesan sesuai tipe media
    keys.forEach((key) => {
        const type = Object.keys(msgs[key].message)[0]; // Mendapatkan jenis media
        if (type.includes("audioMessage")) categorized.vn.push(key);
        else if (type.includes("conversation") || type.includes("extendedTextMessage")) categorized.msg.push(key);
        else if (type.includes("videoMessage")) categorized.video.push(key);
        else if (type.includes("imageMessage")) categorized.img.push(key);
        else if (type.includes("stickerMessage")) categorized.stiker.push(key);
        else if (type.includes("documentMessage") && msgs[key].message[type].mimetype.startsWith("image/gif")) categorized.gif.push(key);
        else categorized.audio.push(key); // Untuk tipe audio lainnya
    });

    // Format daftar pesan yang dikategorikan
    let list = "";
    for (let [category, items] of Object.entries(categorized)) {
        if (items.length > 0) {
            list += `\n*${category.toUpperCase()}*:\n`;
            list += items.map((item, index) => `• ${index + 1}. ${item}`).join("\n") + "\n";
        }
    }

    m.reply(`*List of saved messages categorized:*\n${list.trim()}`);
};

handler.help = ["listmsg"];
handler.tags = ["tools"];
handler.command = /^listmsg$/;

module.exports = handler;