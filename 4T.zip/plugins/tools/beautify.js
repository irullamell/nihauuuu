//© AkiraaBot 2023-2024
// • Credits : wa.me/6287869975929 [ Bang syaii ]
// • Owner: 6285731251154

/*
• untuk siapa pun yang ketahuan menjual script ini tanpa sepengetahuan developer mohon untuk dilaporkan !
*/

module.exports = {
    help: ["beautify", "js-beautify"].map(a => a + " *[Input code]*"),
    tags: ["tools"],
    command: ["beautify", "js-beautify"],
    code: async (m, {
        conn,
        usedPrefix,
        command,
        text,
        isOwner,
        isAdmin,
        isBotAdmin,
        isPrems,
        chatUpdate
    }) => {
        if (!text) throw `*• Example :* ${usedPrefix + command} *[Input code]*`
        m.reply(wait);
        let data = require("js-beautify")(text);
        m.reply(data)
    }
}