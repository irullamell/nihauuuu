//© AkiraaBot 2023-2024
// • Credits : wa.me/6287869975929 [ Bang syaii ]
// • Owner: 6285731251154

/*
• untuk siapa pun yang ketahuan menjual script ini tanpa sepengetahuan developer mohon untuk dilaporkan !
*/

const JavaScriptObfuscator = require("javascript-obfuscator");

let handler = async (m, {
    text,
    usedPrefix,
    command
}) => {
    if (!m.quoted) throw `*• Example :* ${usedPrefix + command} *[reply code]*`;
    const message = await Encrypt(m.quoted.text);
    return m.reply(message);
};

handler.help = ["encrypt", "enc"].map((a) => a + " *[reply code]*");
handler.tags = ["tools"];
handler.command = ["enc", "encrypt"];
handler.limit = true;

module.exports = handler;

async function Encrypt(query) {
    const obfuscationResult = JavaScriptObfuscator.obfuscate(query, {
        compact: false,
        controlFlowFlattening: true,
        controlFlowFlatteningThreshold: 1, // Maximum control flow complexity
        deadCodeInjection: true,
        deadCodeInjectionThreshold: 1, // Maximum dead code injection
        debugProtection: true,
        debugProtectionInterval: 10000, // Increased protection interval
        disableConsoleOutput: true,
        identifierNamesGenerator: 'mangled', // Use mangled names for all identifiers
        log: false,
        numbersToExpressions: true,
        renameGlobals: true,
        rotateStringArray: true,
        selfDefending: true,
        stringArray: true,
        stringArrayEncoding: ['base64', 'rc4'], // Valid encodings
        stringArrayThreshold: 1, // Apply string arrays to all strings
        transformObjectKeys: true,
        transformSyntax: true,
        unicodeEscapeSequence: true,
        arrowFunction: true,
        bigIntLiteral: true,
        classNamesGenerator: 'mangled',
        functionNamesGenerator: 'mangled',
        propertyNamesGenerator: 'mangled',
        splitStrings: true, // Split strings into multiple parts
        splitStringsChunkLength: 3 // Length of split chunks
    });

    let encryptedCode = obfuscationResult.getObfuscatedCode();
    return encryptedCode;
}

async function Decrypt(encryptedCode) {
    // Note: Obfuscation is intended to be hard to reverse engineer.
    throw new Error('Decryption is not supported.');
}