//© Fiestaa
// • Owner: 6285646584823

/*
• untuk siapa pun yang ketahuan menjual script ini tanpa sepengetahuan developer mohon untuk dilaporkan !
*/

const axios = require("axios");
const FormData = require("form-data");
const jimp = require("jimp");

const validScales = [2, 4, 6, 8, 16];
const defaultScale = 2;
const defaultEnhance = false;

async function upscale(buffer, size = defaultScale, anime = defaultEnhance) {
    try {
        if (!Buffer.isBuffer(buffer)) throw new Error("Invalid buffer input");
        if (!validScales.includes(size)) throw new Error("Invalid upscale size");

        const image = await jimp.read(buffer);
        const {
            width,
            height
        } = image.bitmap;
        const newWidth = width * size;
        const newHeight = height * size;

        const form = new FormData();
        form.append("name", `upscale-${Date.now()}`);
        form.append("imageName", `upscale-${Date.now()}`);
        form.append("desiredHeight", newHeight.toString());
        form.append("desiredWidth", newWidth.toString());
        form.append("outputFormat", "png");
        form.append("compressionLevel", "none");
        form.append("anime", anime.toString());
        form.append("image_file", buffer, {
            filename: `upscale-${Date.now()}.png`,
            contentType: "image/png",
        });

        const response = await axios.post("https://api.upscalepics.com/upscale-to-size", form, {
            headers: {
                ...form.getHeaders(),
                origin: "https://upscalepics.com",
                referer: "https://upscalepics.com",
            },
        });

        if (response.data.error) throw new Error("Error from upscaler API.");

        return {
            status: true,
            image: response.data.bgRemoved,
        };
    } catch (error) {
        return {
            status: false,
            message: error.message,
        };
    }
}

const handler = async (m, {
    conn,
    usedPrefix,
    command,
    args
}) => {
    const scale = args[0] ? parseInt(args[0], 10) : defaultScale;
    const enhance = args[1] ? args[1] === "true" : defaultEnhance;

    if (!validScales.includes(scale)) {
        return m.reply(`Nilai untuk upscale harus salah satu dari: ${validScales.join(", ")}.`);
    }

    if (args[1] && !["true", "false"].includes(args[1])) {
        return m.reply(`Apakah foto kartun atau real? jika kartun true, jika real false.`);
    }

    const q = m.quoted ? m.quoted : m;
    const mime = (q.msg || q).mimetype || q.mediaType || "";

    if (!mime) {
        return m.reply(
            `Opsi Penggunaan\n\n1. Fotonya mana? Kirim foto dengan caption ${usedPrefix + command}.\n2. Nilai untuk upscale harus salah satu dari: ${validScales.join(", ")}. (${usedPrefix + command} < nomor >)\n3. Apakah foto kartun atau real? jika kartun true, jika real false. (${usedPrefix + command} < nomor > < true/false>)`,
        );
    }

    if (!/image\/(jpe?g|png)/.test(mime)) {
        return m.reply(`Tipe ${mime} tidak didukung!`);
    }

    await m.reply("Mohon tunggu beberapa menit...");

    let img;
    try {
        img = await q.download();
    } catch (error) {
        return m.reply(`Gagal mendownload gambar: ${error.message}`);
    }

    if (!img) {
        return m.reply("Gagal mendownload gambar.");
    }

    const response = await upscale(img, scale, enhance);

    if (!response.status) {
        return m.reply(`Gagal melakukan upscale: ${response.message}`);
    }

    conn.sendFile(m.chat, response.image, "upscaled.jpg", "Ini dia, Kak!", m);
};

handler.help = ["upscale"];
handler.tags = ["ai"];
handler.command = /^(upscale)$/i;
handler.limit = true;
handler.premium = true;
handler.group = true;

module.exports = handler;