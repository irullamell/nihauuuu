//© AkiraaBot 2023-2024
// • Credits : wa.me/6287869975929 [ Bang syaii ]
// • Owner: 6283831945469,6287869975929

/*
• untuk siapa pun yang ketahuan menjual script ini tanpa sepengetahuan developer mohon untuk dilaporkan !
*/

const { Deobfuscator } = require("deobfuscator");

module.exports = {
  code: async (m, { args, command, usedPrefix }) => {
    const usage = `*• Example :* ${usedPrefix}${command} *[input/reply code]*`;
    let text;
    if (args.length >= 1) {
      text = args.join(" ");
    } else {
      if (!m.quoted || !m.quoted?.text) return m.reply(usage);
      text = m.quoted?.text;
    }

    const message = await Decrypt(text);
    m.reply(message);
  },

  help: ["denc", "dencrypt"].map((a) => a + " *[input/reply code]*"),
  tags: ["tools"],
  command: ["denc", "dencrypt"],
};

async function Decrypt(query) {
  return new Deobfuscator().deobfuscateSource(query);
}
