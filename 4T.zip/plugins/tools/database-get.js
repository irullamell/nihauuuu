//© Fiestaa
// • Owner: 6285646584823

/*
• untuk siapa pun yang ketahuan menjual script ini tanpa sepengetahuan developer mohon untuk dilaporkan !
*/

const {
    proto
} = require("akiraa-baileys");
const fuzz = require('fuzzball'); // Pastikan library fuzzy matching diinstall

const handler = async (m, {
    conn,
    text,
    command,
    usedPrefix
}) => {
    const msgs = db.data.msg || {};

    // Memastikan input teks ada
    if (!text) {
        return m.reply(`*• Contoh penggunaan :* ${usedPrefix + command} *[input text]*\nAnda harus memasukkan kunci pesan untuk mendapatkan media.`);
    }

    // Mengecek jika kunci persis ada
    if (msgs[text]) {
        try {
            const {
                message,
                key
            } = msgs[text];
            if (!message || !key || !key.id) {
                return m.reply(`Pesan dengan kunci *'${text}'* tidak valid atau tidak memiliki media yang dapat dikirim.`);
            }

            const types = Object.keys(message); // Jenis media yang ada dalam pesan
            if (types.length !== 1) {
                return m.reply(`Pesan dengan kunci *'${text}'* harus memiliki tepat satu jenis media untuk dikirim.\nJenis media yang ditemukan: ${types.join(', ')}`);
            }

            // Mengirim ulang pesan
            await conn.relayMessage(m.chat, message, {
                messageId: key.id
            });
            return m.reply(`Berhasil mengirim media: *[ ${text} ]*`);
        } catch (error) {
            // Menangani error jika terjadi selama proses pengiriman pesan
            console.error(error);
            return m.reply(`Terjadi kesalahan saat mencoba mengirim media: ${error.message || error}`);
        }
    }

    // Mencari kunci yang mirip jika kunci persis tidak ditemukan
    const keys = Object.keys(msgs);
    const bestMatch = fuzz.extract(text, keys, {
        scorer: fuzz.ratio,
        limit: 1
    })[0];

    if (bestMatch && bestMatch[1] > 80) { // Threshold kemiripan (80%) untuk kunci mirip
        return m.reply(`Tidak ada pesan persis ditemukan untuk kunci *'${text}'*, tetapi ditemukan kunci mirip: *'${bestMatch[0]}'*\nSilakan gunakan kunci yang tepat.`);
    }

    // Jika tidak ada kunci mirip ditemukan
    return m.reply(`Tidak ditemukan pesan dengan kunci: *'${text}'*\nPeriksa kembali kunci yang Anda masukkan dan pastikan itu valid.`);
};

handler.help = ["vn", "msg", "video", "audio", "img", "stiker", "gif"].map(v => `get${v} *[input text]*`);
handler.tags = ["tools"];
handler.command = /^get(vn|msg|video|audio|img|stic?ker|gif)$/;

module.exports = handler;