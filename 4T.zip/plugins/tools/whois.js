//© AkiraaBot 2023-2024
// • Credits : wa.me/6287869975929 [ Bang syaii ]
// • Owner: 6287869975929,6283831945469

/*
• untuk siapa pun yang ketahuan menjual script ini tanpa sepengetahuan developer mohon untuk dilaporkan !
*/

module.exports = {
  help: ["whois", "lookup"].map((a) => a + " *[domain name]*"),
  tags: ["tools"],
  command: ["whois", "lookup"],
  code: async (
    m,
    {
      conn,
      usedPrefix,
      command,
      text,
      isOwner,
      isAdmin,
      isBotAdmin,
      isPrems,
      chatUpdate,
    },
  ) => {
    if (!text) throw `*• Example :* ${usedPrefix + command} *[domain name]*`;
    let data = await axios.get(
      "https://api.hackertarget.com/dnslookup/?q=" + text,
    );
    m.reply(data.data);
  },
};
