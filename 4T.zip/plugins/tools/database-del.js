//© Fiestaa
// • Owner: 33392090534,6285731251154

/*
• untuk siapa pun yang ketahuan menjual script ini tanpa sepengetahuan developer mohon untuk dilaporkan !
*/

const handler = async (m, {
    text,
    command,
    usedPrefix
}) => {
    db.data.msg = db.data.msg ? db.data.msg : {};
    let msgs = db.data.msg;

    if (!text) {
        throw `*• Example :* ${usedPrefix + command} *[input text]*`;
    }

    if (!(text in msgs)) {
        throw `No message found with the key: '${text}'`;
    }

    // Hapus pesan dari database
    delete msgs[text];

    m.reply(`Successfully deleted the media: *[ ${text} ]*`.trim());
};

handler.help = ["vn", "msg", "video", "audio", "img", "stiker", "gif"].map(
    (v) => "del" + v + " *[input text]*"
);
handler.tags = ["tools"];
handler.command = /^del(vn|msg|video|audio|img|stic?ker|gif)$/;

module.exports = handler;