//© AkiraaBot 2023-2024
// • Credits : wa.me/6287869975929 [ Bang syaii ]
// • Owner: 6287869975929,6283831945469

/*
• untuk siapa pun yang ketahuan menjual script ini tanpa sepengetahuan developer mohon untuk dilaporkan !
*/

let handler = async (m, { conn, text, args, usedPrefix, command }) => {
  let q = m.quoted ? m.quoted : m;
  let mime = (q.msg || q).mimetype || "";
  if (!mime) throw `*• Example :* ${usedPrefix + command} *[reply/send media]*`;
  m.reply(wait);

  try {
    const img = await q.download();
    const data = await Scraper.Tools.removebg(img);
    await conn.sendMessage(
      m.chat,
      {
        image: {
          url: data.image,
        },
        caption: done,
      },
      {
        quoted: m,
      },
    );
  } catch (e) {
    m.reply(eror);
  } finally {
  }
};
handler.help = ["removebg"].map((a) => a + " *[reply/send media]*");
handler.tags = ["tools"];
handler.command = ["removebg"];
handler.limit = true;
handler.register = true;

module.exports = handler;
