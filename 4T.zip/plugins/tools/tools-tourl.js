//© AkiraaBot 2023-2024
// • Credits : wa.me/6287869975929 [ Bang syaii ]
// • Owner: 6287869975929,6283831945469

/*
• untuk siapa pun yang ketahuan menjual script ini tanpa sepengetahuan developer mohon untuk dilaporkan !
*/

//© AkiraaBot 2023-2024
// • Credits : wa.me/6287869975929 [ Bang syaii ]
// • Owner: 6283831945469,6287869975929

/*
• untuk siapa pun yang ketahuan menjual script ini tanpa sepengetahuan developer mohon untuk dilaporkan !
*/

let handler = async (m, { usedPrefix, command }) => {
  let q = m.quoted ? m.quoted : m;
  let mime = (q.msg || q).mimetype || "";

  if (!mime) throw `*• Example:* ${usedPrefix + command} *[reply/send media]*`;
  try {
    let media = await q.download();
    let link = `*[ AKIRAA UPLOADER ]*
> • *Link:* ${await (
      await require(process.cwd() + "/lib/uploader.js").uploadPomf2(
        await q.download(),
      )
    ).files[0].url}`;
    m.reply(link.trim());
  } catch (e) {
    throw e;
  }
};
handler.help = ["tourl", "upload"].map((a) => a + " *[reply/send media]*");
handler.tags = ["tools"];
handler.command = ["tourl", "upload"];

module.exports = handler;
