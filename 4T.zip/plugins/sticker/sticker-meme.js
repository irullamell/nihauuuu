//© Fiestaa
// • Owner: 33392090534,6285731251154

/*
• untuk siapa pun yang ketahuan menjual script ini tanpa sepengetahuan developer mohon untuk dilaporkan !
*/

let handler = async (m, {
    conn,
    text,
    usedPrefix,
    command
}) => {
    if (!text) throw `*• Example :* ${usedPrefix + command} *[upper|lower]*`;
    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || "";
    if (!mime) throw `*• Example :* ${usedPrefix + command} *[upper|lower]*`;
    let [atas, bawah] = text.split(`|`);
    m.reply(wait);
    let img = await q.download();
    let url = await require("../../lib/uploader.js").catbox(img)
    let meme = `https://api.memegen.link/images/custom/${encodeURIComponent(atas ? atas : "")}/${encodeURIComponent(bawah ? bawah : "")}.png?background=${url}`;
    conn.sendImageAsSticker(m.chat, meme, m, {
        packname: packname,
        author: author,
    });
};
handler.help = ["stickermeme", "smeme"].map((a) => a + " *[upper|lower]*");
handler.tags = ["sticker"];
handler.command = ["stickermeme", "smeme"];
handler.limit = true;

module.exports = handler;