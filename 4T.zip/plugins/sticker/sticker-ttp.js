//© AkiraaBot 2023-2024
// • Credits : wa.me/6287869975929 [ Bang syaii ]
// • Owner: 6287869975929,6283831945469

/*
• untuk siapa pun yang ketahuan menjual script ini tanpa sepengetahuan developer mohon untuk dilaporkan !
*/

const { exec } = require("child_process");
const fs = require("fs");
const util = require("util");
const execPromise = util.promisify(exec);

const ttp = async (text, fontPath, outputPath) => {
  const verticalText = text.split("").join("\n"); // Buat teks menjadi vertikal
  const command = `convert -background transparent -fill white -font ${fontPath} -pointsize 85 -gravity Center label:'${verticalText}' ${outputPath}`;

  try {
    await execPromise(command);
    console.log(`TTP berhasil dibuat ✅`);
    return fs.readFileSync(outputPath);
  } catch (error) {
    console.error(`Error saat membuat TTP: ${error.message}`);
    throw error;
  }
};

module.exports = {
  help: ["ttp"].map((a) => +" *[input text]*"),
  tags: ["tools"],
  command: ["ttp"],
  code: async (
    m,
    {
      conn,
      usedPrefix,
      command,
      text,
      isOwner,
      isAdmin,
      isBotAdmin,
      isPrems,
      chatUpdate,
    },
  ) => {
    if (!text) throw `*• Example :* ${usedPrefix + command} *[input text]*`;
    m.reply(wait);
    let data = await ttp(
      text,
      process.cwd() + "/database/212BabyGirl.ttf",
      process.cwd() + "/tmp/ttp.png",
    );
    conn.sendImageAsSticker(m.chat, data, m, {
      packname: global.packname,
      author: global.author,
    });
  },
};
