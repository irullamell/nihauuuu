let nodemailer = require('nodemailer')
let handler = async function(m, {
    conn,
    args,
    usedPrefix,
    command
}) {
    try {
        let users = global.db.data.users[m.sender]
        let name = await conn.getName(m.sender)
        if (users.registered === true) return conn.reply(m.chat, Func.texted('bold', `✅ Your number already verified.`), m)
        if (!args || !args[0]) return conn.reply(m.chat, `• *Example :* .${command} ${global.email}`, m)
        await conn.sendMessage(m.chat, {
            react: {
                text: '🕒',
                key: m.key
            }
        })
        if (!/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/ig.test(args[0])) return conn.reply(m.chat, Func.texted('bold', '🚩 Invalid email.'), m)
        let code = `${getRandomInt(100, 900)}-${getRandomInt(100, 900)}`
        let kemii = conn.user.jid.split("@")[0]
        users.codeExpire = new Date * 1
        users.code = code
        users.email = args[0]
        let transport = nodemailer.createTransport({
            service: 'gmail',
            auth: {
                user: "dcodekemii2@gmail.com",
                pass: 'sgzn tsxm ovfv durt'
            }
        })


        let mailOptions = {
            from: {
                name: 'Kikuchanj',
                address: 'dcodekemii2@gmail.com'
            },
            to: args[0],
            subject: 'Email Verification',
            html: `<div style="padding:20px;border:1px dashed #222;font-size:15px"><tt>Hi <b>${name}</b><br><br><img src="https://i.ibb.co.com/DGXB6Yx/IMG-20240803-WA0275.jpg" alt="Thumbnail"><br><br>Confirm your email to be able to use Kikuchanj. Send this code to the bot and it will expire in 3 minutes.<br><center><h1>${code}</h1></center>Or copy and paste the URL below into your browser : <a href="https://wa.me/${kemii}?text=${code}">https://wa.me/${kemii}?text=${code}</a><br><br><hr style="border:0px; border-top:1px dashed #222"><br>Powered by: <b>WhatsApp bot</b></tt></div>`
        }
        transport.sendMail(mailOptions, function(err, data) {
            if (err) return m.reply(Func.texted('bold', `❌ SMTP Error !!`))
            return conn.reply(m.chat, Func.texted('bold', `✅ Check your mailbox to get a verification code.`), m)
        })
    } catch (e) {
        conn.reply(m.chat, Func.jsonFormat(e), m)
    }

}
handler.help = ['reg *<email>*']
handler.tags = ['start']

handler.command = /^(reg|regmail)$/i
handler.private = false

module.exports = handler

function getRandomInt(min, max) {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min + 1)) + min;
}