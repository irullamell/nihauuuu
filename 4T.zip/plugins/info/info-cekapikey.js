let handler = async (m, { conn, text, usedPrefix, command }) => {
  let result = await (
    await Func.fetchJson(
      "https://api.lolhuman.xyz/api/checkapikey?apikey=Akiraa",
    )
  ).result;
  let cap = `*[ CEK STATUS APIKEY ]*
*• Username :* ${result.username}
*• Rank Api :* ${result.account_type}
*• Total Request :* ${Func.formatNumber(result.requests)}
*• Today Request :* ${Func.formatNumber(result.today)}
*• Expired :* ${result.expired}

_Upgrade Apikey minta ke syaii wir_`;
  conn.sendButton(
    m.chat,
    [
      ["BACK TO MENU", "menu"],
      ["OWNER BOT", "owner"],
      ["SERVER INFO", "ping"],
    ],
    m,
    {
      body: cap,
    },
  );
};
handler.help = ["cekapikey"].map((a) => a + " *[check status apikey]*");
handler.tags = ["info"];
handler.command = ["cekapikey"];

module.exports = handler;
