//© AkiraaBot 2023-2024
// • Credits : wa.me/6287869975929 [ Bang syaii ]
// • Owner: 6285731251154

/*
• untuk siapa pun yang ketahuan menjual script ini tanpa sepengetahuan developer mohon untuk dilaporkan !
*/

let handler = async (m, {
    conn,
    text,
    usedPrefix,
    command
}) => {
    conn.sendUrl(
        m.chat,
        [
            [
                "Join Channel Bot",
                "https://whatsapp.com/channel/0029VanIpIQEawdmkoT5vI11",
            ],
        ],
        m, {
            body: `Not For sell`,
        },
    );
};
handler.help = ["sc", "script"].map((a) => a + " *[get script]*");
handler.tags = ["info"];
handler.command = ["sc", "script"];

module.exports = handler;