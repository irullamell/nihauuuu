//© Fiestaa
// • Owner: 6285646584823

/*
• untuk siapa pun yang ketahuan menjual script ini tanpa sepengetahuan developer mohon untuk dilaporkan !
*/

const moment = require("moment-timezone");
const os = require("os");

const freeMemory = os.freemem();
const totalMemory = os.totalmem();
const usedMemory = totalMemory - freeMemory;

const formatSize = (size) => {
    const units = ["B", "KB", "MB", "GB", "TB"];
    let i = 0;
    while (size >= 1024 && i < units.length - 1) {
        size /= 1024;
        i++;
    }
    return `${size.toFixed(1)} ${units[i]}`;
};

const getAllCommandsWithCategories = () => {
    let categorizedCommands = {};

    Object.values(global.plugins)
        .filter(v => !v.disabled)
        .forEach(v => {
            const tags = Array.isArray(v.tags) ? v.tags : ["others"];
            const helps = Array.isArray(v.help) ? v.help : [];

            if (helps.length === 0) return; // Skip if no help is defined

            tags.forEach(tag => {
                if (!categorizedCommands[tag]) {
                    categorizedCommands[tag] = [];
                }
                helps.forEach(helpItem => {
                    if (helpItem) { // Ensure helpItem is defined and valid
                        categorizedCommands[tag].push(`│○ ${helpItem}`);
                    }
                });
            });
        });

    let result = "";
    Object.keys(categorizedCommands).forEach(category => {
        result += `\n┌──⭓ _${category.toUpperCase()}_\n${categorizedCommands[category].join("\n")}\n└─────────────\n`;
    });
    return result;
};

module.exports = {
    help: ["menu *[view main menu]*", "menu all *[view all commands]*"],
    tags: ["main"],
    command: ["menu"],
    code: async (m, {
        conn,
        usedPrefix,
        args
    }) => {
        const commandType = args[0] || "main";
        const user = global.db.data.users[m.sender];
        const name = m.pushName || conn.getName(m.sender);
        const fitur = Object.values(global.plugins).filter(v => !v.disabled).map(v => v.help).flat(1);

        if (commandType === "all") {
            const allCommandsWithCategories = getAllCommandsWithCategories();
            const allMenuMessage = `
Hi @${m.sender.split("@")[0]},

*All Available Commands by Category:*
${allCommandsWithCategories}

Total Features: ${fitur.length}
            `;

            conn.reply(m.chat, allMenuMessage.trim(), m);
        } else {
            const menuMessage = `
Hi @${m.sender.split("@")[0]},

*Bot Info:*
- Name: ${conn.user.name}
- Total Users: ${Object.keys(db.data.users).length}
- Total Features: ${fitur.length}
- Free Memory: ${formatSize(freeMemory)}
- Used Memory: ${formatSize(usedMemory)}
- Total Memory: ${formatSize(totalMemory)}

Type *${usedPrefix}menu all* to view all commands.
            `;

            conn.reply(m.chat, menuMessage.trim(), m);
        }
    },
};