//© AkiraaBot 2023-2024
// • Credits : wa.me/6287869975929 [ Bang syaii ]
// • Owner: 6287869975929,6283831945469

/*
• untuk siapa pun yang ketahuan menjual script ini tanpa sepengetahuan developer mohon untuk dilaporkan !
*/

const handler = async (m, { conn }) => {
  if (!m.quoted) throw `*• Example :* .ci *[reply message]*`;
  const quotedObj = await m.getQuotedObj();
  const id = quotedObj.msg.contextInfo.forwardedNewsletterMessageInfo;
  let teks = "```Channel Name: ```" + "" + `${id.newsletterName}` + "\n";
  teks += "```Channel Id: ```" + " " + `${id.newsletterJid}` + "";
  await conn.reply(m.chat, teks.trim(), m);
};

handler.help = ["ci *Reply pesan dari channel*"];
handler.command = ["ci"];
handler.tags = ["tools"];

module.exports = handler;
