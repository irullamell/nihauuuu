let handler = async (m, { conn, text, usedPrefix, command }) => {
  conn.sendButton(m.chat, [["🙏 YOUR WELCOME", "sama sama"]], m, {
    body: `${htki} SPECIAL THANK FOR ${htka}

*• BOTCAHX ( BASE SCRIPT )*
*• NEOXR ( INSPIRED )*
*• SYAII ( OWNER AKIRAABOT )*
*• Malik ( HELPER )*
*• Daffa ( SCRAPER )*
*• AKIRAA-TEAM ( MY SUPPORT )*

🚩 Terimakasih Support bot ini, kami menghargai jasa anda karena telah membeli script secara ori dari *@bang_syaii*

*<===================================>*
Semoga Kedepannya Script ini akan jauh lebih baik dari sekarang`,
  });
};
handler.help = ["tqto"].map((a) => a + " *[credits script]*");
handler.tags = ["info"];
handler.command = ["tqto"];

module.exports = handler;
