//© Fiestaa
// • Owner: 6285646584823

/*
• untuk siapa pun yang ketahuan menjual script ini tanpa sepengetahuan developer mohon untuk dilaporkan !
*/

const os = require("os");
const {
    performance
} = require("perf_hooks");
const {
    sizeFormatter
} = require("human-readable");

const format = sizeFormatter({
    std: "JEDEC",
    decimalPlaces: 2,
    keepTrailingZeroes: false,
    render: (literal, symbol) => `${literal} ${symbol}B`,
});

const handler = async (m, {
    conn
}) => {
    const start = performance.now();

    // Send an initial reply to start timing ping
    await m.reply("_Mengukur ping..._");

    const end = performance.now();
    const ping = end - start;

    const chats = Object.entries(conn.chats).filter(
        ([id, data]) => id && data.isChats
    );
    const groupsIn = chats.filter(([id]) => id.endsWith("@g.us"));
    const usedMemory = process.memoryUsage();
    const totalMemory = os.totalmem();

    // Calculate precise CPU usage
    const cpuUsageStart = process.cpuUsage();
    const elapsedTimeStart = performance.now();

    // Small delay for accurate CPU usage calculation
    await new Promise(resolve => setTimeout(resolve, 100));

    const cpuUsageEnd = process.cpuUsage(cpuUsageStart);
    const elapsedTimeEnd = performance.now();
    const elapsedTime = elapsedTimeEnd - elapsedTimeStart;

    // Convert CPU usage time to percentage
    const cpuUsagePercentage = ((cpuUsageEnd.user + cpuUsageEnd.system) / 1000) / (elapsedTime / 1000) * 100;

    const uptime = process.uptime();
    const ramUsage = usedMemory.rss; // Resident Set Size (RAM used by the process)

    const txt = `*ᴘ ɪ ɴ ɢ*
• Ping: ${ping.toFixed(2)} ms

*ʀ ᴜ ɴ ᴛ ɪ ᴍ ᴇ* 
• ${formatUptime(uptime)}

*ᴄ ʜ ᴀ ᴛ s*
• *${groupsIn.length}* Group Chats
• *${chats.length - groupsIn.length}* Personal Chats
• *${chats.length}* Total Chats

*s ᴇ ʀ ᴠ ᴇ ʀ*
• RAM Usage: ${format(ramUsage)} / ${format(totalMemory)} (${((ramUsage / totalMemory) * 100).toFixed(2)}%)
• Platform: ${os.platform()}
• Hostname: ${os.hostname()}
• CPU Usage: ${cpuUsagePercentage.toFixed(2)}%
`;

    m.reply(txt);
};

handler.help = ["ping", "speed"].map(a => a + " *[get info server]*");
handler.tags = ["info"];
handler.command = ["ping", "speed"];

module.exports = handler;

function formatUptime(seconds) {
    const d = Math.floor(seconds / 86400);
    const h = Math.floor(seconds % 86400 / 3600);
    const m = Math.floor(seconds % 3600 / 60);
    const s = Math.floor(seconds % 60);
    return `${d}D ${h}H ${m}M ${s}S`;
}