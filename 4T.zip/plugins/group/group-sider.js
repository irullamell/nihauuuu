//© AkiraaBot 2023-2024
// • Credits : wa.me/6287869975929 [ Bang syaii ]
// • Owner: 6285731251154

/*
• untuk siapa pun yang ketahuan menjual script ini tanpa sepengetahuan developer mohon untuk dilaporkan !
*/

let handler = async (m, {
    conn,
    text,
    groupMetadata,
    args
}) => {
    // Pastikan handler dipanggil di dalam grup
    if (!m.isGroup) {
        return conn.reply(m.chat, 'Perintah ini hanya dapat digunakan dalam grup.', m);
    }

    // Pastikan metadata grup tersedia
    if (!groupMetadata || !groupMetadata.participants) {
        return conn.reply(m.chat, 'Gagal mendapatkan data grup. Coba lagi nanti.', m);
    }

    await conn.sendPresenceUpdate('composing', m.chat);

    // Konfigurasi Waktu Tidak Aktif (default: 7 hari)
    let hariTidakAktif = args[0] ? parseInt(args[0]) : 7;
    let lama = 86400000 * hariTidakAktif;

    // Threshold aktivitas (misalnya, hanya pengguna dengan lastseen lebih dari 3 hari yang dianggap tidak aktif)
    let thresholdAktif = args[1] ? parseInt(args[1]) : 3;
    let lamaAktif = 86400000 * thresholdAktif;

    const now = new Date().toLocaleString("en-US", {
        timeZone: "Asia/Jakarta"
    });
    const milliseconds = new Date(now).getTime();

    // Pesan default atau custom
    let pesan = text ? text : "Harap aktif di grup karena akan ada pembersihan member setiap saat";

    // Daftar pengguna yang tidak akan pernah dihapus
    let pengecualian = ['admin@s.whatsapp.net', '1234567890@s.whatsapp.net']; // Ganti dengan JID pengguna yang dikecualikan

    let member = groupMetadata.participants.map(v => v.id);
    let totalSider = 0;
    let totalDihapus = 0;
    let sider = [];

    for (let id of member) {
        // Skip pengguna yang ada di daftar pengecualian
        if (pengecualian.includes(id)) continue;

        let user = groupMetadata.participants.find(u => u.id == id);
        let userData = global.db.data.users[id];

        if ((!userData || milliseconds - userData.lastseen > lama) && !user?.isAdmin && !user?.isSuperAdmin) {
            totalSider++;
            sider.push(id);

            // Opsi: Hapus pengguna jika tidak aktif lebih dari X hari
            if (milliseconds - userData?.lastseen > lamaAktif && args.includes('--remove')) {
                await conn.groupParticipantsUpdate(m.chat, [id], 'remove');
                totalDihapus++;
            }
        }
    }

    if (totalSider === 0) {
        return conn.reply(m.chat, `*Di grup ini tidak ada anggota yang tidak aktif.*`, m);
    }

    let siderList = sider.map(id => {
        let lastActive = global.db.data.users[id] ? msToDate(milliseconds - global.db.data.users[id].lastseen) : 'Tidak Diketahui';
        return `• @${id.split('@')[0]} (Terakhir aktif: ${lastActive})`;
    }).join('\n');

    conn.reply(m.chat, `*${totalSider}/${member.length}* Anggota grup *${await conn.getName(m.chat)}* adalah tidak aktif.\n\n_“${pesan}”_\n\n*Daftar Member Tidak Aktif:*\n${siderList}\n\n${totalDihapus > 0 ? `*${totalDihapus}* Anggota telah dihapus karena tidak aktif.` : ''}`, m, {
        contextInfo: {
            mentionedJid: sider
        }
    });
}

handler.help = ['gcsider <hari> <threshold> [--remove] [--log] [pesan]'];
handler.tags = ['group'];
handler.command = /^(gcsider)$/i;
handler.group = true;

module.exports = handler;

function msToDate(ms) {
    let days = Math.floor(ms / 86400000);
    let hours = Math.floor(ms / 3600000) % 24;
    let minutes = Math.floor(ms / 60000) % 60;

    if (days > 0) {
        return `${days} Hari ${hours} Jam`;
    } else if (hours > 0) {
        return `${hours} Jam ${minutes} Menit`;
    } else {
        return `${minutes} Menit`;
    }
}