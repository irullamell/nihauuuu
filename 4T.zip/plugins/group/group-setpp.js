const fs = require("fs");
const Jimp = require("jimp");
let handler = (module.exports = {
  help: ["setppgc"].map((a) => a + " *[reply/send media]*"),
  tags: ["group"],
  command: ["setppgc"],
  admin: true,
  group: true,
  code: async (m, { conn, usedPrefix, command }) => {
    var image = m.quoted ? m.quoted : m;
    var mime = (image.msg || image).mimetype || "";
    if (!mime)
      throw `*• Example :* ${usedPrefix + command} *[reply/send media]*`;
    var media = await image.download();
    const group = m.chat;
    var { img } = await generateProfilePicture(media);
    await conn.query({
      tag: "iq",
      attrs: {
        to: group,
        type: "set",
        xmlns: "w:profile:picture",
      },
      content: [
        {
          tag: "picture",
          attrs: { type: "image" },
          content: img,
        },
      ],
    });
    m.reply(
      `Success Update Profile Group : *[. ${await conn.getName(m.chat)} ]*`,
    );
  },
});

async function generateProfilePicture(buffer) {
  const jimp_1 = await Jimp.read(buffer);
  const minz =
    jimp_1.getWidth() > jimp_1.getHeight()
      ? jimp_1.resize(720, Jimp.AUTO)
      : jimp_1.resize(Jimp.AUTO, 720);
  const jimp_2 = await Jimp.read(await minz.getBufferAsync(Jimp.MIME_JPEG));
  return {
    img: await minz.getBufferAsync(Jimp.MIME_JPEG),
  };
}
