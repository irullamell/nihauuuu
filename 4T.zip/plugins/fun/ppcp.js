//© AkiraaBot 2023-2024
// • Credits : wa.me/6287869975929 [ Bang syaii ]
// • Owner: 6287869975929,6283831945469

/*
• untuk siapa pun yang ketahuan menjual script ini tanpa sepengetahuan developer mohon untuk dilaporkan !
*/

module.exports = {
  help: ["ppcouple", "ppcp"].map((a) => a + " *[random pp]*"),
  tags: ["fun"],
  command: ["ppcouple", "ppcp"],
  code: async (
    m,
    {
      conn,
      usedPrefix,
      command,
      text,
      isOwner,
      isAdmin,
      isBotAdmin,
      isPrems,
      chatUpdate,
    },
  ) => {
    m.reply(wait);
    let data = Func.random(await Scraper["Random"].ppcouple());
    if (data.cewe) {
      m.reply(done, data.cewe);
    }
    if (data.cowo) {
      m.reply(done, data.cowo);
    }
  },
};
