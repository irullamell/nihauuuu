//© Fiestaa
// • Owner: 33392090534,6285731251154

/*
• untuk siapa pun yang ketahuan menjual script ini tanpa sepengetahuan developer mohon untuk dilaporkan !
*/

let cooldowns = {};

module.exports = {
    help: ["cariteman"].map((a) => a + " *[random tag]*"),
    tags: ["fun"],
    command: ["cariteman"],
    code: async (
        m, {
            conn,
            usedPrefix,
            command,
            text,
            isOwner,
            isAdmin,
            isBotAdmin,
            isPrems,
            chatUpdate,
        },
    ) => {
        const user = db.data.users;
        const cooldownTime = 5 * 60 * 1000; // 5 minutes in milliseconds
        const userId = m.sender;

        if (!cooldowns[userId]) {
            cooldowns[userId] = 0; // Initialize cooldown if it doesn't exist
        }

        const lastUsed = cooldowns[userId];
        const now = Date.now();

        if (now - lastUsed < cooldownTime) {
            const remainingTime = Math.ceil((cooldownTime - (now - lastUsed)) / 1000);
            const minutes = Math.floor(remainingTime / 60);
            const seconds = remainingTime % 60;
            return conn.reply(
                m.chat,
                `Please wait ${minutes} minute(s) and ${seconds} second(s) before using this command again.`,
                m
            );
        }

        // Update the cooldown to the current timestamp
        cooldowns[userId] = now;

        // Proceed with the original command logic
        const random = Func.random(Object.keys(user));
        const cap = `*[ RANDOM FRIENDS ]*
*• Name :* ${await conn.getName(random)}
*• Tags :* @${random.split("@")[0]}

Click the button to send a message to a random friend!`;

        conn.sendUrl(
            m.chat,
            [
                [
                    "Chat now",
                    `https://wa.me/${random.split("@")[0]}?text=temenan+yuk?`,
                ],
            ],
            m, {
                body: cap,
            },
        );
    },
};