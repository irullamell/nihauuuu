//© AkiraaBot 2023-2024
// • Credits : wa.me/6287869975929 [ Bang syaii ]
// • Owner: 6287869975929,6283831945469

/*
• untuk siapa pun yang ketahuan menjual script ini tanpa sepengetahuan developer mohon untuk dilaporkan !
*/
const ytdl = require("node-yt-dl");
const fs = require("fs");
const { pipeline } = require("stream");
const { promisify } = require("util");
const streamPipeline = promisify(pipeline);
const os = require("os");

module.exports = {
  help: ["play"].map((a) => a + " *[query]*"),
  tags: ["downloader"],
  command: ["play"],
  code: async (
    m,
    {
      conn,
      usedPrefix,
      command,
      text,
      isOwner,
      isAdmin,
      isBotAdmin,
      isPrems,
      chatUpdate,
    },
  ) => {
    if (!text) throw `*• Example:* ${usedPrefix + command} *[query]*`;
    m.reply(wait); // Assuming 'wait' is defined somewhere

    let data = await ytdl.search(text);
    let src = data.data[Math.floor(Math.random() * data.data.length)];
    let download = await ytdl.mp3(src.url);
    let cap = `${download.title}\n\n* *Metadata :*\n${Object.entries(
      download.metadata,
    )
      .map(([a, b]) => `* ${a} : ${b}`)
      .join("\n")}\n\n* *Author :*\n${Object.entries(download.author)
      .map(([a, b]) => `* ${a} : ${b}`)
      .join("\n")}\n\nPlease wait, audio has been sent...`;

    let t = await conn.reply(m.chat, cap, m, {
      contextInfo: {
        externalAdReply: {
          showAdAttribution: true,
          mediaType: 2,
          mediaUrl: download.url,
          title: download.title,
          body: download.metadata.description, // Replace 'wm' with the correct variable or string
          sourceUrl: download.url,
          thumbnail: await (
            await conn.getFile(download.metadata.thumbnail)
          ).data,
        },
      },
    });
    let doc = {
      audio: {
        url: download.media,
      },
      mimetype: "audio/mp4",
      fileName: `${download.title}`,
      contextInfo: {
        externalAdReply: {
          showAdAttribution: true,
          mediaType: 2,
          mediaUrl: download.url,
          title: download.title,
          body: download.metadata.description, // Replace 'wm' with the correct variable or string
          sourceUrl: download.url,
          thumbnail: await (
            await conn.getFile(download.metadata.thumbnail)
          ).data,
        },
      },
    };

    await conn.sendMessage(m.chat, doc, {
      quoted: t,
    });
  },
};
