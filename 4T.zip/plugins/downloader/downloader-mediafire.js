let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `*• Example :* ${usedPrefix + command} *[url mediaFire]*`;
  if (!Func.isUrl(text))
    throw `*• Example :* ${usedPrefix + command} *[url mediaFire]*`;
  m.reply(wait);
  try {
    let data = await Scraper.Download.mediafire(text);
    let cap = `*[ MEDIAFIRE DOWNLOADER ]*
*• Title :* ${data.title}
*• Size :* ${data.size}
*• Url :* ${data.url}`;
    let file = await conn.getFile(data.url, true);
    conn.sendMessage(
      m.chat,
      {
        document: file.data,
        fileName: data.title,
        mimetype: file.mime,
        caption: cap,
      },
      { quoted: m },
    );
  } catch (e) {
    throw eror;
  }
};
handler.help = ["mediafire", "mf"].map((a) => a + " *[url mediaFire]*");
handler.tags = ["downloader"];
handler.command = ["mediafire", "mf"];

module.exports = handler;
