//© AkiraaBot 2023-2024
// • Credits : wa.me/6287869975929 [ Bang syaii ]
// • Owner: 6287869975929,6283831945469

/*
• untuk siapa pun yang ketahuan menjual script ini tanpa sepengetahuan developer mohon untuk dilaporkan !
*/

let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `*• Example :* ${usedPrefix + command} *[Instagram url]*`;
  if (!Func.isUrl(text))
    throw `*• Example :* ${usedPrefix + command} *[Instagram url]*`;
  m.reply(wait);
  try {
    let media = await Func.fetchJson(
      "https://widipe.com/download/igdl?url=" + text,
    );
    if (media.length === 0) throw "*[ NO MEDIA FOUND ]*";
    for (let i of media.result) {
      m.reply("*[ INSTAGRAM DOWNLOADER ]*", i.url);
    }
  } catch (e) {
    throw eror;
  }
};
handler.help = ["ig", "igdl"].map((a) => a + " *[Instagram url]*");
handler.tags = ["downloader"];
handler.command = ["ig", "igdl"];

module.exports = handler;
