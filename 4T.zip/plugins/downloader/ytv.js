//© Fiestaa
// • Owner: 6285646584823

/*
• untuk siapa pun yang ketahuan menjual script ini tanpa sepengetahuan developer mohon untuk dilaporkan !
*/

const axios = require("axios");

let handler = async (m, {
    conn,
    usedPrefix,
    command,
    text
}) => {
    switch (command) {
        case "ytv":
        case "ytmp4": {
            if (!text) throw `*• Example :* ${usedPrefix + command} https://youtu.be/VPIom0Azrkg`
            m.reply("Downloading....")
            let {
                data
            } = await axios.get("https://api.botwa.space/api/ytmp4?url=" + text + "&apikey=GfoyVOlqHFLG").catch((e) => e.response);

            if (!data.result) return data.message;

            // Default value for metadata if undefined
            let metadata = data.result.metadata || {};
            let cap = `${data.result.title}

* *Metadata Info :*
${Object.entries(metadata).map(([a, b]) => `- ${a} : ${b}`).join("\n")}

YouTube Downloader by ${data.creator}`;

            await conn.sendMessage(m.chat, {
                video: {
                    url: data.result.media
                },
                caption: cap
            }, {
                quoted: m
            });
        }
        break;
    }
}

handler.help = handler.command = ["ytmp4", "ytv"];
handler.tags = ["downloader"];

module.exports = handler;