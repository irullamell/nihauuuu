//© AkiraaBot 2023-2024
// • Credits : wa.me/6287869975929 [ Bang syaii ]
// • Owner: 6287869975929,6283831945469

/*
• untuk siapa pun yang ketahuan menjual script ini tanpa sepengetahuan developer mohon untuk dilaporkan !
*/

module.exports = {
  help: ["apk"].map((a) => a + " *[apk name]*"),
  tags: ["downloader"],
  command: ["apk"],
  code: async (
    m,
    {
      conn,
      usedPrefix,
      command,
      text,
      isOwner,
      isAdmin,
      isBotAdmin,
      isPrems,
      chatUpdate,
    },
  ) => {
    conn.apk = conn.apk ? conn.apk : {};
    if (!text) throw `*• Example :* ${usedPrefix + command} *[apk name]*`;
    m.reply(wait);
    let data = await Scraper.Download.aptoide.search(text);
    let cap = `Reply this message with input number *1 -> ${data.length}* for Download

${data.map((a, i) => `${i + 1}. ${a.name}`).join("\n")}

© Powered by aptoide downloader`;
    m.reply(cap);
    conn.apk[m.sender] = data;
  },
  before: async (m, { conn }) => {
    conn.apk = conn.apk ? conn.apk : {};
    if (!m.text) return;
    if (m.isCommand) return;
    if (isNaN(m.text)) return;
    if (!conn.apk[m.sender]) return;
    conn.apk = conn.apk ? conn.apk : {};
    let data = await conn.apk[m.sender];
    let pilih = data[m.text - 1];
    let download = await Scraper.Download.aptoide.download(pilih.id);
    m.reply(wait);
    let cap = `Success Downloading Apk !
* *Name :* ${download.appname}
* *Developer :* ${download.developer}`;
    conn.sendMessage(
      m.chat,
      {
        document: {
          url: download.link,
        },
        caption: cap,
        mimetype: "application/zip",
        jpegThumbnail: await conn.resize(download.img, 100, 100),
      },
      {
        quoted: m,
      },
    );
  },
};
