
async function before(m, { isAdmin, isBotAdmin}) {
const chat = db.data.chats[m.chat]
const regexp =
    /https:\/\/(whatsapp|chat).whatsapp.com\/([a-zA-Z0-9]+(\/[0-9]+)?)/;
  if (m.isGroup) {
    let isGroupLink = regexp.test(m.text);
    if (!isBotAdmin) return;
    if (isAdmin) return;
    if (m.formMe) return;
    if (chat.antiLink && isGroupLink) {
      m.reply(
        `*[ System Detected ]* you sent another group link, I will delete this`,
      );
      conn.sendMessage(m.chat, {
        delete: {
          ...m.key,
        },
      });
    }
  }
}

module.exports = { before }