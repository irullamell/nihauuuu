//© Fiestaa
// • Owner: 6285646584823

/*
• untuk siapa pun yang ketahuan menjual script ini tanpa sepengetahuan developer mohon untuk dilaporkan !
*/

async function before(m, {
    isAdmin,
    isBotAdmin
}) {
    // Inisialisasi database pesan jika belum ada
    db.data.msg = db.data.msg ? db.data.msg : {};

    // Jika pesan berasal dari Baileys atau tidak memiliki teks, atau merupakan perintah, lanjutkan tanpa memproses
    if (m.isBaileys || !m.text || m.isCommand) return;

    let msgs = db.data.msg;
    // Mencari kunci yang mirip di database pesan
    let result = Object.keys(msgs).find((a) => m.text.toLowerCase().includes(a));

    // Jika tidak ada kunci yang cocok, lanjutkan tanpa memproses
    if (!result) return;

    // Jika pengirim adalah admin atau bot admin, atau jika pengiriman pesan diperlukan, hentikan pengiriman
    // Dalam hal ini, kita tidak mengirimkan apapun
    // return; // Menghindari pengiriman pesan

    // Mengserialize pesan
    let _m = conn.serializeM(
        JSON.parse(JSON.stringify(msgs[result]), (_, v) =>
            null !== v &&
            "object" == typeof v &&
            "type" in v &&
            "Buffer" === v.type &&
            "data" in v &&
            Array.isArray(v.data) ?
            Buffer.from(v.data) :
            v,
        ),
    );

    // Jika kode ini aktif, pesan akan dikirimkan. Namun, jika kita tidak ingin mengirimkan pesan,
    // bagian ini tidak perlu ada, sehingga tidak perlu mengirimkan pesan sama sekali
    // await _m.copyNForward(m.chat);
}

module.exports = {
    before
};