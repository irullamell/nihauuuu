//© Fiestaa
// • Owner: 6285646584823

/*
• untuk siapa pun yang ketahuan menjual script ini tanpa sepengetahuan developer mohon untuk dilaporkan !
*/

let fs = require("fs");

var handler = (m) => m;
danz.all = async function(m) {
    var setting = db.data.settings;
    updateBio(); // Panggil updateBio() saat pertama kali dipanggil

    // Set interval untuk update bio setiap 5 menit
    setInterval(() => {
        updateBio();
    }, 300000); // 300000 ms = 5 menit

    setting.status = new Date() * 1;
};

module.exports = handler;

async function updateBio() {
    var _uptime = process.uptime() * 1000;
    var uptime = clockString(_uptime);
    await danz.setBio(
        `${global.wm} | Runtime: ${uptime} |  Mode: ${global.opts["self"] ? "Private" : opts["gconly"] ? "Group" : "Publik"} | Version: ${version}`,
    ).catch((_) => _);
}

function clockString(ms) {
    var h = isNaN(ms) ? "--" : Math.floor(ms / 3600000);
    var m = isNaN(ms) ? "--" : Math.floor(ms / 60000) % 60;
    var s = isNaN(ms) ? "--" : Math.floor(ms / 1000) % 60;
    return [h, m, s].map((v) => v.toString().padStart(2, "0")).join(":");
}