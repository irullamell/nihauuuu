//© AkiraaBot 2023-2024
// • Credits : wa.me/6287869975929 [ Bang syaii ]
// • Owner: 6283831945469,6287869975929

/*
• untuk siapa pun yang ketahuan menjual script ini tanpa sepengetahuan developer mohon untuk dilaporkan !
*/

module.exports = {
  before: async (m, { conn }) => {
    if (m.isBaileys || !m.message || !m.message.editedMessage) return;
    const editedMsg = m.message.editedMessage;
    if (
      editedMsg.imageMessage ||
      editedMsg.videoMessage ||
      editedMsg.documentMessage ||
      (editedMsg.editedMessage &&
        (editedMsg.editedMessage.imageMessage ||
          editedMsg.editedMessage.videoMessage ||
          editedMsg.editedMessage.documentMessage))
    ) {
      return;
    }
    await conn.appendTextMessage(
      m,
      editedMsg.message?.protocolMessage?.editedMessage?.extendedTextMessage
        ?.text || editedMsg.extendedTextMessage?.text,
      m.chatUpdate,
    );
  },
};
