//© AkiraaBot 2023-2024
// • Credits : wa.me/6287869975929 [ Bang syaii ]
// • Owner: 6287869975929,6283831945469

/*
• untuk siapa pun yang ketahuan menjual script ini tanpa sepengetahuan developer mohon untuk dilaporkan !
*/

const fs = require('fs');
const path = require('path');
const cron = require('node-cron');
const timezone = 'Asia/Jakarta';
let resetLimit = true;
let maghribTime = true;
let maghribOver = true;

function filterGroups(groupId) {
    return store.groupMetadata[groupId].participants.filter(participant => participant.admin !== null);
}

function includesAdmin(participants, groupId) {
    return !!participants.find(participant => participant.id === groupId);
}

module.exports = {
        before: async (m, {
            conn
        }) => {
            try {
                const groupIds = Object.values(store.groupMetadata)
                const getParticipants = async () => {
                    let participants = await conn.groupFetchAllParticipating();
                    return Object.values(participants);
                };

                // Maghrib Announcements
                cron.schedule('* * * * *', async () => {
                        let now = require("moment-timezone").tz(timezone).format("HH:mm")
                        if (now === "05:00") {
                            let participants = await getParticipants();
                            let announcement = 'Selamat pagi semuanya waktu sudah menunjukkan jam 05:00 Wib sudah waktunya saya untuk membuka Group ini selamat beraktifitas semuanya ^^.';

                            if (maghribTime) {
                                maghribTime = false;
                                for (let group of participants) {
                                    if (groupIds.includes(group.id) && db.data.chats[group.id].scheducle && group.announce && includesAdmin(filterGroups(group.id), conn.user.jid)) {
                                        await conn.groupSettingUpdate(group.id, 'not_announcement').then(() => conn.sendMessage(group.id, {
                                                text: announcement
                                            }, {
                                                quoted: fakestatus('Group Notification')
                                            }); await Func.delay(1000);
                                        }
                                    }
                                }
                            }
                            console.log(`[TIME] ${now} WIB`);
                        }, {
                            scheduled: true,
                            timezone
                        });

                }
                catch (error) {
                    return error
                }
            }
        }