//© Fiestaa
// • Owner: 33392090534,6285731251154

/*
• untuk siapa pun yang ketahuan menjual script ini tanpa sepengetahuan developer mohon untuk dilaporkan !
*/

const {
    Sticker
} = require("akiraa-wb");
const axios = require("axios");
const fs = require("fs");
const path = require("path");

// File paths
const defaultColorFilePath = path.join(__dirname, "defaultColor.json");
const userColorFilePath = path.join(__dirname, "userColors.json");
const themeFilePath = path.join(__dirname, "themes.json");

// Load or initialize the default color
let defaultColor = "#292232";
if (fs.existsSync(defaultColorFilePath)) {
    const fileContent = fs.readFileSync(defaultColorFilePath, "utf-8");
    const data = JSON.parse(fileContent);
    defaultColor = data.color || "#292232";
}

// Load or initialize user colors
let userColors = {};
if (fs.existsSync(userColorFilePath)) {
    const fileContent = fs.readFileSync(userColorFilePath, "utf-8");
    userColors = JSON.parse(fileContent);
}

// Load or initialize themes
let themes = {};
if (fs.existsSync(themeFilePath)) {
    const fileContent = fs.readFileSync(themeFilePath, "utf-8");
    themes = JSON.parse(fileContent);
}

// Function to format date and time
const formatDateTime = () => {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const seconds = String(now.getSeconds()).padStart(2, '0');

    const date = `${year}-${month}-${day}`;
    const time = `${hours}:${minutes}:${seconds}`;

    return `${date} ${time}`;
};

// Function to validate hex color
const isValidHex = (color) => /^#[0-9A-F]{6}$/i.test(color);

const handler = async (m, {
    conn,
    args
}) => {
    const q = m.quoted ? m.quoted : m;
    const mime = (q.msg || q).mimetype || "";
    let reply;
    if (!m.quoted) {
        reply = {};
    } else if (!q.sender === q.sender) {
        reply = {
            name: q.name,
            text: q.text || "",
            chatId: q.chat.split("@")[0],
        };
    }

    // Command handling
    if (args[0] === "setcolor") {
        if (args.length < 2 || !isValidHex(args[1])) {
            return conn.sendMessage(m.chat, {
                text: "*• Example :* .qc setcolor #hex\n*• Note:* Please provide a valid hex color code."
            }, {
                quoted: m
            });
        }
        const userId = m.sender;
        const color = args[1];
        userColors[userId] = {
            backgroundColor: color,
            textColor: color,
            borderColor: color,
            accentColor: color
        };
        fs.writeFileSync(userColorFilePath, JSON.stringify(userColors, null, 2));
        return conn.sendMessage(m.chat, {
            text: `Color settings updated to *${color}*. Use *#qc resetcolor* to revert.`
        }, {
            quoted: m
        });
    }

    if (args[0] === "resetcolor") {
        const userId = m.sender;
        if (userColors[userId]) {
            delete userColors[userId];
            fs.writeFileSync(userColorFilePath, JSON.stringify(userColors, null, 2));
            return conn.sendMessage(m.chat, {
                text: "Your color settings have been reset to default."
            }, {
                quoted: m
            });
        } else {
            return conn.sendMessage(m.chat, {
                text: "No custom color settings found."
            }, {
                quoted: m
            });
        }
    }

    if (args[0] === "settheme") {
        if (args.length < 2 || !themes[args[1]]) {
            return conn.sendMessage(m.chat, {
                text: "*• Example :* .qc settheme [theme_name]\n*• Note:* Choose a valid theme from the list."
            }, {
                quoted: m
            });
        }
        const userId = m.sender;
        const themeName = args[1];
        userColors[userId] = themes[themeName];
        fs.writeFileSync(userColorFilePath, JSON.stringify(userColors, null, 2));
        return conn.sendMessage(m.chat, {
            text: `Theme set to *${themeName}*. Use *#qc resetcolor* to revert to default settings.`
        }, {
            quoted: m
        });
    }

    if (args[0] === "listthemes") {
        const themeList = Object.keys(themes).map(theme => `*${theme}*: ${JSON.stringify(themes[theme], null, 2)}`).join("\n\n");
        return conn.sendMessage(m.chat, {
            text: `Available themes:\n\n${themeList}`
        }, {
            quoted: m
        });
    }

    // Determine the color for the user
    const userId = m.sender;
    let userTheme = userColors[userId] || {
        backgroundColor: defaultColor,
        textColor: "#FFFFFF",
        borderColor: "#333333",
        accentColor: "#888888",
        textStyle: {
            font: "Arial",
            size: "20px",
            alignment: "center"
        }
    };

    // Extract text and optional color from args
    let text = "";
    const colorIndex = args.indexOf("--color");

    if (args.length >= 1) {
        if (colorIndex !== -1 && args[colorIndex + 1]) {
            const customColor = args[colorIndex + 1];
            if (isValidHex(customColor)) {
                userTheme.backgroundColor = customColor;
                args.splice(colorIndex, 2);
            } else {
                return conn.sendMessage(m.chat, {
                    text: "*• Invalid color code. Please use a valid hex color code (e.g., #ff5733).*"
                }, {
                    quoted: m
                });
            }
        }
        text = args.join(" ");
    } else if (m.quoted) {
        text = m.quoted.text || "";
    } else {
        return conn.sendMessage(m.chat, {
            text: "*• Example :* .qc *[text or reply message]* --color #hex (optional)"
        }, {
            quoted: m
        });
    }

    const img = await q.download?.();
    const pp = await conn
        .profilePictureUrl(q.sender, "image")
        .catch((_) => "https://telegra.ph/file/320b066dc81928b782c7b.png");

    const dateTime = formatDateTime();

    const obj = {
        type: "quote",
        format: "png",
        backgroundColor: userTheme.backgroundColor,
        textColor: userTheme.textColor,
        borderColor: userTheme.borderColor,
        accentColor: userTheme.accentColor,
        width: 512,
        height: 768,
        scale: 2,
        messages: [{
            entities: [],
            media: mime ? {
                url: await Uploader.Uguu(img),
            } : undefined,
            avatar: true,
            from: {
                id: m.chat.split("@")[0],
                name: q.name,
                photo: {
                    url: pp,
                },
            },
            text: text || "",
            replyMessage: reply,
        }],
        textStyle: userTheme.textStyle
    };

    try {
        const json = await axios.post(
            "https://quotly.netorare.codes/generate",
            obj, {
                headers: {
                    "Content-Type": "application/json",
                },
            }
        );

        const buffer = Buffer.from(json.data.result.image, "base64");
        const stickerResult = await Sticker.sticker5(
            buffer,
            false,
            `Bubble chat sticker\n`,
            `Tiktok: @irulldenji\nDibuat pada: ${dateTime}\n`,
        );

        if (stickerResult)
            return conn.sendFile(m.chat, stickerResult, "Quotly.webp", "", m);
    } catch (error) {
        console.error("Error generating sticker:", error);
        return conn.sendMessage(m.chat, {
            text: "An error occurred while generating the sticker. Please try again later."
        }, {
            quoted: m
        });
    }
};

handler.help = [
    "qc *[text or reply message]*",
    "qc setcolor #hex",
    "qc resetcolor",
    "qc settheme [theme_name]",
    "qc listthemes"
];
handler.tags = ["sticker"];
handler.command = ["qc"];
handler.limit = true

module.exports = handler;