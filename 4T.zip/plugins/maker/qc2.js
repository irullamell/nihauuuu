//© Fiestaa
// • Owner: 33392090534,6285731251154

/*
• untuk siapa pun yang ketahuan menjual script ini tanpa sepengetahuan developer mohon untuk dilaporkan !
*/

const {
    Sticker
} = require("akiraa-wb");
const axios = require("axios");
const fs = require("fs");
const path = require("path");

const defaultColorFilePath = path.join(__dirname, "defaultColor.json");
const userColorFilePath = path.join(__dirname, "userColors.json");

// Load or initialize the default color
let defaultColor = "#292232";
if (fs.existsSync(defaultColorFilePath)) {
    const fileContent = fs.readFileSync(defaultColorFilePath, "utf-8");
    const data = JSON.parse(fileContent);
    defaultColor = data.color || "#292232";
}

// Load or initialize user colors
let userColors = {};
if (fs.existsSync(userColorFilePath)) {
    const fileContent = fs.readFileSync(userColorFilePath, "utf-8");
    userColors = JSON.parse(fileContent);
}

const handler = async (m, {
    conn,
    args
}) => {
    const q = m.quoted ? m.quoted : m;
    const mime = (q.msg || q).mimetype || "";
    let reply;
    if (!m.quoted) {
        reply = {};
    } else if (!q.sender === q.sender) {
        reply = {
            name: q.name,
            text: q.text || "",
            chatId: q.chat.split("@")[0],
        };
    }

    // Check if the command is setcolor or resetcolor
    if (args[0] === "setcolor") {
        if (args.length < 2) {
            return conn.sendMessage(m.chat, {
                text: "*• Example :* .qc setcolor #hex"
            }, {
                quoted: m
            });
        }
        const userId = m.sender;
        const color = args[1];
        userColors[userId] = color;
        fs.writeFileSync(userColorFilePath, JSON.stringify(userColors, null, 2));
        return conn.sendMessage(m.chat, {
            text: `Default color for you set to *${color}*\n\nType *#qc resetcolor* to reset`
        }, {
            quoted: m
        });
    }

    // Handle resetcolor command
    if (args[0] === "resetcolor") {
        const userId = m.sender;
        if (userColors[userId]) {
            delete userColors[userId];
            fs.writeFileSync(userColorFilePath, JSON.stringify(userColors, null, 2));
            return conn.sendMessage(m.chat, {
                text: "Your color has been reset to default."
            }, {
                quoted: m
            });
        } else {
            return conn.sendMessage(m.chat, {
                text: "You have not set a custom color yet."
            }, {
                quoted: m
            });
        }
    }

    // Determine the color for the user
    const userId = m.sender;
    let color = userColors[userId] || defaultColor; // Use user-specific color or default

    // Extract text and optional color from args
    let text = "";
    const colorIndex = args.indexOf("--color");

    if (args.length >= 1) {
        // If --color is present, extract color
        if (colorIndex !== -1 && args[colorIndex + 1]) {
            color = args[colorIndex + 1];
            args.splice(colorIndex, 2); // Remove --color and its value
        }
        text = args.join(" ");
    } else if (m.quoted) {
        text = m.quoted.text || "";
    } else {
        throw "*• Example :* .qc *[text or reply message]* --color #hex (optional)";
    }

    const img = await q.download?.();
    const pp = await conn
        .profilePictureUrl(q.sender, "image")
        .catch((_) => "https://telegra.ph/file/320b066dc81928b782c7b.png");

    // Convert hex color to rgba with 50% transparency
    function hexToRgba(hex, alpha = 0.5) {
        let r = 0,
            g = 0,
            b = 0;
        if (hex.length === 4) {
            r = parseInt(hex[1] + hex[1], 16);
            g = parseInt(hex[2] + hex[2], 16);
            b = parseInt(hex[3] + hex[3], 16);
        } else if (hex.length === 7) {
            r = parseInt(hex[1] + hex[2], 16);
            g = parseInt(hex[3] + hex[4], 16);
            b = parseInt(hex[5] + hex[6], 16);
        }
        return `rgba(${r}, ${g}, ${b}, ${alpha})`;
    }

    const rgbaColor = hexToRgba(color, 0.5); // Apply 50% transparency

    const obj = {
        type: "quote",
        format: "png",
        backgroundColor: rgbaColor, // Use rgba color with transparency
        width: 512,
        height: 768,
        scale: 2,
        messages: [{
            entities: [],
            media: mime ? {
                url: await Uploader.Uguu(img),
            } : undefined,
            avatar: true,
            from: {
                id: m.chat.split("@")[0],
                name: q.name,
                photo: {
                    url: pp,
                },
            },
            text: text || "",
            replyMessage: reply,
        }],
    };

    const json = await axios.post(
        "https://quotly.netorare.codes/generate",
        obj, {
            headers: {
                "Content-Type": "application/json",
            },
        }
    );

    const buffer = Buffer.from(json.data.result.image, "base64");
    const stickerResult = await Sticker.sticker5(
        buffer,
        false,
        "Bubble chat sticker\n",
        "Tiktok: @irulldenji\n"
    );

    if (stickerResult)
        return conn.sendFile(m.chat, stickerResult, "Quotly.webp", "", m);
};

handler.help = [
    "qc2 *[text or reply message]*",
    "qc2 setcolor #hex",
    "qc2 resetcolor"
];
handler.tags = ["sticker"];
handler.command = ["qc2"];
handler.limit = true

module.exports = handler;