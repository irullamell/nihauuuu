/*💥 *SCRAPE ONDOKU3*
- Text to Speech
- Image to Speech

🧑‍💻 Base Url : https://ondoku3.com/

🌑 *Mod* :
- Bypass Limit Request API ( *Image to Speech* )

💥 Script Code by Daffa
*/

const axios = require("axios");
const jsdom = require("jsdom");
const { JSDOM } = jsdom;
const FormData = require("form-data");
const fs = require("fs");
const path = require("path");

class Ondoku3 {
  constructor() {
    this.url = "https://ondoku3.com/id/text_to_speech/";
    this.mainUrl = "https://ondoku3.com/id/";
    this.headers = {
      "User-Agent": "Postify/1.0.0",
      Accept: "*/*",
      "Accept-Language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
      "Cache-Control": "no-cache",
      Pragma: "no-cache",
      "Upgrade-Insecure-Requests": "1",
      Origin: "https://ondoku3.com",
      Referer: "https://ondoku3.com/id/",
      "Sec-Ch-Ua": '"Not-A.Brand";v="99", "Chromium";v="58"',
      "Sec-Ch-Ua-Mobile": "?0",
      "Sec-Ch-Ua-Platform": '"Windows"',
      "Sec-Fetch-Dest": "empty",
      "Sec-Fetch-Mode": "cors",
      "Sec-Fetch-Site": "same-origin",
      "X-Requested-With": "XMLHttpRequest",
    };
  }

  randomIP() {
    const ip = `${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}`;
    return ip;
  }

  async fecthToken() {
    try {
      const response = await axios.get(this.mainUrl, { headers: this.headers });
      const dom = new JSDOM(response.data);
      const tokenNa = dom.window.document.querySelector(
        'input[name="csrfmiddlewaretoken"]',
      );
      if (!tokenNa) throw new Error("❎ Gak nemu token nya 😂");
      const tokenValue = tokenNa.value;
      this.csrfToken = tokenValue;

      return tokenValue;
    } catch (error) {
      console.error(error);
      return null;
    }
  }

  async scrape(data, voiceId) {
    try {
      const csrfToken = await this.fecthToken();
      if (!csrfToken) throw new Error("❎ Gak nemu token nya 😂");

      const formHeaders = data.getHeaders();
      const randomIp = this.randomIP();
      const headers = {
        ...formHeaders,
        ...this.headers,
        Cookie: `settings={"voice":"${voiceId}","speed":1,"pitch":0,"language":"id-ID"}; csrftoken=${csrfToken}`,
        "x-csrftoken": csrfToken,
        "X-Forwarded-For": randomIp,
      };
      const response = await axios.post(this.url, data, {
        headers: headers,
      });
      return response.data;
    } catch (error) {
      if (error.response) {
        console.error(error.response.data);
        throw new Error(error.response.data);
      } else {
        console.error(error.message);
        throw new Error(error.message);
      }
    }
  }

  async textToSpeech(text, voiceId = "id-ID-Wavenet-B") {
    const data = new FormData();
    data.append("text", text);
    data.append("voice", voiceId);
    data.append("speed", "1");
    data.append("pitch", "0");

    return this.scrape(data, voiceId);
  }

  async imageToSpeech(filePath, voiceId = "id-ID-Wavenet-B") {
    try {
      const base64Image = await this.convertImage(filePath);
      const data = new FormData();
      data.append("image_0", base64Image);
      data.append("text", "");
      data.append("voice", voiceId);
      data.append("speed", "1");
      data.append("pitch", "0");

      return this.scrape(data, voiceId);
    } catch (error) {
      console.error(error);
      throw error;
    }
  }

  async convertImage(filePath) {
    try {
      const fileBuffer = filePath;
      const base64Image =
        "data:image/jpeg;base64," + fileBuffer.toString("base64");
      return base64Image;
    } catch (error) {
      console.error(error);
      throw error;
    }
  }
}

module.exports = Ondoku3;
