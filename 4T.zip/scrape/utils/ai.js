const axios = require("axios");
const cheerio = require("cheerio");
const fetch = require("node-fetch");
const qs = require("qs");
const _ = require("lodash");
const jimp = require('jimp');

const LetmeGpt = async (query) => {
  const encodedQuery = encodeURIComponent(query);
  const url = `https://letmegpt.com/search?q=${encodedQuery}`;

  try {
    const response = await axios.get(url);
    const $ = cheerio.load(response.data);
    return $("#gptans").text() || null;
  } catch (error) {
    console.error("Error fetching LetmeGpt data:", error);
    throw error;
  }
};

const generateRandomID = (length) => {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
  return _.sampleSize(chars, length).join("");
};

// Fungsi untuk mengambil data dari leptonAi
const leptonAi = async (query) => {
  try {
    const client = axios.create({
      baseURL: "https://search.lepton.run/api/",
      headers: { "Content-Type": "application/json" },
    });
    const requestId = generateRandomID(10);
    const payload = { query, rid: requestId };
    const response = await client.post("query", payload);
    const match = response.data.match(
      /__LLM_RESPONSE__([\s\S]*?)__RELATED_QUESTIONS__/,
    );

    if (match?.[1]) {
      return match[1].trim();
    } else {
      throw new Error("No LLM response found.");
    }
  } catch (error) {
    console.error("Error fetching leptonAi response:", error);
    throw new Error("Error fetching LLM response: " + error.message);
  }
};

// Fungsi untuk bertanya ke SimSimi
const Simsimi = async (query) => {
  const url = "https://simsimi.vn/web/simtalk";
  try {
    const response = await axios.post(
      url,
      `text=${encodeURIComponent(query)}&lc=id`,
      {
        headers: {
          "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
          Accept: "application/json, text/javascript, */*; q=0.01",
          "X-Requested-With": "XMLHttpRequest",
          "User-Agent":
            "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36",
          Referer: "https://simsimi.vn/",
        },
      },
    );
    return response.data.success || null;
  } catch (error) {
    console.error("Error asking SimSimi:", error);
    throw error;
  }
};

// Fungsi untuk bertanya ke GoodyAI
const GoodyAI = async (message) => {
  try {
    const response = await axios.post(
      "https://www.goody2.ai/send",
      {
        message,
        debugParams: null,
      },
      {
        headers: {
          Accept: "*/*",
          "Accept-Encoding": "gzip, deflate, br, zstd",
          "Accept-Language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7,af;q=0.6",
          "Content-Type": "application/json",
          Origin: "https://www.goody2.ai",
          Referer: "https://www.goody2.ai/chat",
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
        },
        responseType: "stream",
      },
    );

    return new Promise((resolve, reject) => {
      let result = "";
      response.data.on("data", (chunk) => {
        const lines = chunk.toString().split("\n");
        lines.forEach((line) => {
          if (line.startsWith('data: {"content":')) {
            try {
              const content = JSON.parse(line.slice(6)).content;
              result += content;
            } catch (jsonError) {
              console.error("Error parsing JSON:", jsonError);
            }
          }
        });
      });
      response.data.on("end", () => resolve(result));
      response.data.on("error", reject);
    });
  } catch (error) {
    console.error("Error asking GoodyAI:", error);
    throw error;
  }
};

// Fungsi untuk bertanya ke CgtAi
const CgtAi = async (message) => {
  try {
    const payload = {
      conversation_uuid: 100,
      text: message,
      sent_messages: 1,
    };
    const response = await axios.post(
      "https://www.timospecht.de/wp-json/cgt/v1/chat",
      qs.stringify(payload),
      {
        headers: {
          "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
          Accept: "*/*",
          "X-Requested-With": "XMLHttpRequest",
        },
      },
    );
    return response.data?.data?.message;
  } catch (error) {
    console.error("Error fetching CgtAi data:", error);
    throw new Error("Terjadi kesalahan:", error);
  }
};

// Fungsi untuk bertanya ke thinkany
const thinkany = async (message) => {
  try {
    const response = await axios.post(
      "https://thinkany.ai/api/chat",
      {
        role: "user",
        content: message,
        conv_uuid: 100,
        mode: "search",
        is_new: true,
        model: "claude-3-haiku",
      },
      { headers: { "Content-Type": "application/json" } },
    );
    return response.data;
  } catch (error) {
    console.error("Error fetching thinkany data:", error);
    throw error;
  }
};

// Fungsi untuk bertanya ke Degree Guru
const degreeguru = async (userMessage, systemMessage) => {
  try {
    const response = await fetch("https://degreeguru.vercel.app/api/guru", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        messages: [
          {
            role: "system",
            content: systemMessage || "You The best Ai Degereeguru !",
          },
          { role: "user", content: userMessage },
        ],
      }),
    });
    if (!response.ok) throw new Error("Network response was not ok");
    return await response.text();
  } catch (error) {
    console.error("Error calling Degree Guru API:", error.message);
    throw error;
  }
};

// Fungsi untuk bertanya ke Ragbot
const ragbot = async (userMessage, systemMessage) => {
  try {
    const response = await fetch("https://ragbot-starter.vercel.app/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        messages: [
          { role: "system", content: systemMessage || "I'am Ragbot 😀💪" },
          { role: "user", content: userMessage },
        ],
        useRag: true,
        llm: "gpt-3.5-turbo",
        similarityMetric: "cosine",
      }),
    });
    if (!response.ok) throw new Error("Network response was not ok");
    return await response.text();
  } catch (error) {
    console.error("Error calling Ragbot API:", error.message);
    throw error;
  }
};

const stoicai = async (userMessage, systemMessage) => {
  try {
    const response = await fetch("https://app.stoiccord.com/api/completion", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        messages: [
          { role: "system", content: systemMessage || "Hello 😀😊" },
          { role: "user", content: userMessage },
        ],
      }),
    });
    if (!response.ok) throw new Error("Network response was not ok");
    return await response.text();
  } catch (error) {
    console.error("Error calling stoic API:", error.message);
    throw error;
  }
};

// Fungsi untuk bertanya ke stoicgpt
const stoicgpt = async (userMessage, systemMessage) => {
  try {
    const response = await fetch("https://app.stoiccord.com/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        messages: [
          { role: "system", content: systemMessage || "👋 Hello" },
          { role: "user", content: userMessage },
        ],
      }),
    });
    if (!response.ok) throw new Error("Network response was not ok");
    return await response.text();
  } catch (error) {
    console.error("Error calling stoic API:", error.message);
    throw error;
  }
};
const detectText = (text) => {
  return new Promise(async (resolve, reject) => {
    axios
      .post(
        "https://api.gptzero.me/v2/predict/text",
        {
          document: text,
        },
        {
          headers: {
            "Content-Type": "application/json",
            Cookie:
              "AMP_MKTG_8f1ede8e9c=JTdCJTIycmVmZXJyZXIlMjIlM0ElMjJodHRwcyUzQSUyRiUyRmlkLnNlYXJjaC55YWhvby5jb20lMkYlMjIlMkMlMjJyZWZlcnJpbmdfZG9tYWluJTIyJTNBJTIyaWQuc2VhcmNoLnlhaG9vLmNvbSUyMiU3RA==; accessToken4=eyJhbGciOiJIUzI1NiIsImtpZCI6IkxQUGtRbDRKRlQvcmY5VkoiLCJ0eXAiOiJKV1QifQ.eyJhdWQiOiJhdXRoZW50aWNhdGVkIiwiZXhwIjoxNjk1MjM1Mzg4LCJpYXQiOjE2OTQ2MzA1ODgsImlzcyI6Imh0dHBzOi8vaHR0cHM6Ly9seWRxaGdkemh2c3FsY29iZGZ4aS5zdXBhYmFzZS5jby9hdXRoL3YxIiwic3ViIjoiOWYyZTRhMTItMTE3Zi00YjIxLWFmY2UtMDg2MzE0ODQyZGM2IiwiZW1haWwiOiJhcGkuZW5kcG9pbnRleHBlcnRAZ21haWwuY29tIiwicGhvbmUiOiIiLCJhcHBfbWV0YWRhdGEiOnsicHJvdmlkZXIiOiJnb29nbGUiLCJwcm92aWRlcnMiOlsiZ29vZ2xlIl19LCJ1c2VyX21ldGFkYXRhIjp7ImF2YXRhcl91cmwiOiJodHRwczovL2xoMy5nb29nbGV1c2VyY29udGVudC5jb20vYS9BQ2c4b2NMakxya1hEVnQ1VVU5ekZBXzR6V1J6VlFCMHA1dHJDamtsTDdld0NMdGtoZz1zOTYtYyIsImVtYWlsIjoiYXBpLmVuZHBvaW50ZXhwZXJ0QGdtYWlsLmNvbSIsImVtYWlsX3ZlcmlmaWVkIjp0cnVlLCJmdWxsX25hbWUiOiJhcGkgZW5kcG9pbnRleHBlcnQiLCJpc3MiOiJodHRwczovL2FjY291bnRzLmdvb2dsZS5jb20iLCJuYW1lIjoiYXBpIGVuZHBvaW50ZXhwZXJ0IiwicGljdHVyZSI6Imh0dHBzOi8vbGgzLmdvb2dsZXVzZXJjb250ZW50LmNvbS9hL0FDZzhvY0xqTHJrWERWdDVVVTl6RkFfNHpXUnpWUUIwcDV0ckNqa2xMN2V3Q0x0a2hnPXM5Ni1jIiwicHJvdmlkZXJfaWQiOiIxMDMwMzEwMjg5MDU0NTg4Njk3ODIiLCJzdWIiOiIxMDMwMzEwMjg5MDU0NTg4Njk3ODIifSwicm9sZSI6ImF1dGhlbnRpY2F0ZWQiLCJhYWwiOiJhYWwxIiwiYW1yIjpbeyJtZXRob2QiOiJvYXV0aCIsInRpbWVzdGFtcCI6MTY5NDYzMDU4OH1dLCJzZXNzaW9uX2lkIjoiZTg4NGNiYzYtY2U3Yy00NDk1LWIxOTktNDA0Mjg4MTg1YzViIn0.Pjr91l1-bVcRrd-jkmiPQOzrwYG0bv6fSeFY6bSAH3k; AMP_8f1ede8e9c=JTdCJTIyZGV2aWNlSWQlMjIlM0ElMjI3OGE3MjJhZi1mMmJlLTQ4OGItOTQwNy1iZGUyNDZjYTA4YTklMjIlMkMlMjJzZXNzaW9uSWQlMjIlM0ExNjk0NjI5ODc0MDExJTJDJTIyb3B0T3V0JTIyJTNBZmFsc2UlMkMlMjJsYXN0RXZlbnRUaW1lJTIyJTNBMTY5NDYzMDc5MzY0NyUyQyUyMmxhc3RFdmVudElkJTIyJTNBMTElN0Q=",
            "User-Agent":
              "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36",
          },
        },
      )
      .then((response) => {
        resolve(response.data);
      })
      .catch((error) => {
        reject(error);
      });
  });
};
const defaultApiKey = 'AIzaSyAY8DjFZHICDZ-TeHNN6lnEFoB-qczmXxE';

class Gemini {
    constructor(apiKey = defaultApiKey) {
        this.apiKey = apiKey;
    }

    conversation = async(text) => {
        const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=${this.apiKey}`;
        const headers = { 'Content-Type': 'application/json' };
        const body = {
            contents: [
                {
                    parts: [
                        { text: text }
                    ]
                }
            ]
        };
        const response = await axios.post(url, body, { headers: headers });
        return response.data.candidates[0].content.parts[0].text;
    }

   image  = async(imageUrl, text) => {
        const imageBuffer = await this.bufferImage(imageUrl);
        const resizedBuffer = await this.resizeImage(imageBuffer);
        const body = {
            contents: [
                {
                    parts: [
                        { text: text },
                        { inline_data: { mime_type: 'image/jpeg', data: resizedBuffer.toString('base64') } }
                    ]
                }
            ]
        };
        const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${this.apiKey}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body)
        });
        const data = await response.json();
        return data.candidates[0].content.parts[0].text;
    }

    async bufferImage(imageUrl) {
        const response = await axios.get(imageUrl, { responseType: 'arraybuffer' });
        return Buffer.from(response.data);
    }

    async resizeImage(imageBuffer) {
        const image = await jimp.read(imageBuffer);
        const resizedBuffer = await image.resize(512, 512).getBufferAsync(jimp.MIME_JPEG);
        return resizedBuffer;
    }
}
class BoredHumans {
  constructor() {
    this.BASE = "https://boredhumans.com";
    this.BASE_URL = this.BASE + "/apis/boredagi_api.php";
    this.BASE_CDN = this.BASE + "/boredagi_files";
    this.BASE_UPLOAD = this.BASE + "/apis/boredagi_upload.php";
    this.uid = {};
    this.sesh_id = {};
    this.tools = {
      celebrity_ai: 10,
      txt2img: 3,
      img_recognition: 6,
      txt2speech: 116,
    };
    this.num = 0;
    this.text = {
      10: "I want to talk to someone famous.",
      3: "Can you generate an image?",
      6: "Describe this image for me.",
      116: "Connect me to Text-To-Speech (TTS) Tool",
    };
  }

  // ? FUNCTION
  #getUid() {
    this.uid[this.num] =
      Date.now().toString(36) + Math.random().toString(36).slice(2);
  }

  async #getSeshId() {
    await this.#getUid();
    const res = await fetch(this.BASE_URL, {
      method: "POST",
      headers: {
        "User-Agent": navigator.userAgent,
      },
      body: new URLSearchParams({
        prompt: encodeURIComponent(this.text[this.num]),
        uid: this.uid[this.num],
        sesh_id: "None",
        get_tool: false,
        tool_num: this.num,
      }),
    }).then((v) => v.json());
    if (res.status !== "success") return (this.sesh_id[this.num] = "none");
    return (this.sesh_id[this.num] = res.sesh_id);
  }

  // ? AI
  celebrityAi = async function celebrityAi(prompt) {
    return new Promise(async (resolve, reject) => {
      try {
        this.num = this.tools.celebrity_ai;
        if (!this.sesh_id[this.num]) await this.#getSeshId();
        const data = new URLSearchParams({
          prompt: encodeURIComponent(prompt),
          uid: this.uid[this.num],
          sesh_id: this.sesh_id[this.num],
          get_tool: false,
          tool_num: this.num,
        });

        const res = await fetch(this.BASE_URL, {
          method: "POST",
          headers: {
            "User-Agent": navigator.userAgent,
          },
          body: data,
        }).then((v) => v.json());
        if (res.status !== "success")
          return (async () => {
            await this.#getSeshId();
            await this.celebrityAi(prompt);
          })();
        return resolve(res.output);
      } catch (e) {
        reject(e);
      }
    });
  }

 txt2img = async function txt2img(prompt) {
    return new Promise(async (resolve, reject) => {
      try {
        this.num = this.tools.txt2img;
        if (!this.sesh_id[this.num]) await this.#getSeshId();
        const data = {
          prompt: encodeURIComponent(prompt),
          uid: this.uid[this.num],
          sesh_id: this.sesh_id[this.num],
          get_tool: false,
          tool_num: this.num,
        };

        const res = await fetch(this.BASE_URL, {
          method: "POST",
          headers: {
            "User-Agent": navigator.userAgent,
          },
          body: new URLSearchParams(data),
        })
          .then((v) => v.json())
          .then((v) =>
            (async () => {
              data.prompt = "yes";

              return await fetch(this.BASE_URL, {
                method: "POST",
                headers: {
                  "User-Agent": navigator.userAgent,
                },
                body: new URLSearchParams(data),
              }).then((v) => v.json());
            })()
          );

        if (res.status !== "success")
          return (async () => {
            await this.#getSeshId();
            await this.txt2img(prompt);
          })();
        const $ = cheerio.load(res.output);
        await this.#getSeshId();
        return resolve($("img").attr("src"));
      } catch (e) {
        reject(e);
      }
    });
  }

imageRecognition = async function imageRecognition(url, prompt) {
    return new Promise(async (resolve, reject) => {
      try {
        this.num = this.tools.img_recognition;
        if (!this.sesh_id[this.num]) await this.#getSeshId();

        const data = new URLSearchParams({
          prompt: encodeURIComponent(url),
          uid: this.uid[this.num],
          sesh_id: this.sesh_id[this.num],
          get_tool: false,
          tool_num: this.num,
        });

        fetch(this.BASE_URL, {
          method: "POST",
          headers: {
            "User-Agent": navigator.userAgent,
          },
          body: data,
        })
          .then((v) => v.json())
          .then((v) =>
            (async () => {
              data.set("prompt", encodeURIComponent(prompt));
              fetch(this.BASE_URL, {
                method: "POST",
                headers: {
                  "User-Agent": navigator.userAgent,
                },
                body: data,
              })
                .then((v) => v.json())
                .then((v) => async () => {
                  await this.#getSeshId();
                  resolve(v.output);
                });
            })()
          );
      } catch (e) {
        reject(e);
      }
    });
  }

 txt2speech = async function txt2speech(prompt) {
    return new Promise(async (resolve, reject) => {
      try {
        this.num = this.tools.txt2speech;
        if (!this.sesh_id[this.num]) await this.#getSeshId();
        const data = new URLSearchParams({
          prompt: encodeURIComponent(prompt),
          uid: this.uid[this.num],
          sesh_id: this.sesh_id[this.num],
          get_tool: false,
          tool_num: this.num,
        });

        fetch(this.BASE_URL, {
          method: "POST",
          headers: {
            "User-Agent": navigator.userAgent,
          },
          body: data,
        })
          .then((v) => v.json())
          .then((v) =>
            (async () => {
              await this.#getSeshId();
              return resolve(v.output);
            })()
          );
      } catch (e) {
        reject(e);
      }
    });
  }
}

async function stableDiff(prompt, negative = "") {
  return new Promise(async (resolve, reject) => {
    try {
      if (!prompt) return reject("Enter Prompt!");
      const res = await fetch(
        "https://requesteracessibili.joaovitorkas13.workers.dev",
        {
          method: "POST",
          headers: {
            authority: "requesteracessibili.joaovitorkas13.workers.dev",
            "content-type": "application/json",
            origin: "https://just4demo24.blogspot.com",
            referer: "https://just4demo24.blogspot.com/",
            "user-agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
          },
          body: JSON.stringify({
            prompt: prompt,
            negative_prompt: negative,
            sync_mode: 1,
          }),
        }
      ).then((v) => v.json());

      return resolve(res);
    } catch (e) {
      reject(e);
    }
  });
}
async function animagine(options = {}) {
  return new Promise(async (resolve, reject) => {
    try {
      let {
        prompt = "Cute Cat",
        negative = "Not Real",
        style = "Anime",
        sampler = "Euler a",
        ratio = "896 x 1152",
        quality = "Standard",
        width = "1024",
        height = "1024",
      } = options;
      const BASE_URL = "https://linaqruf-animagine-xl.hf.space";
      const session_hash = Math.random().toString(36).substring(2);

      // ? Checker
      if (
        !/\(None\)|Cinematic|Photographic|Anime|Manga|Digital Art|Pixel art|Fantasy art|Neonpunk|3D Model/.test(
          style
        )
      )
        style = "Anime";
      if (
        !/DDIM|Euler a|Euler|DPM\+\+ 2M Karras|DPM\+\+ 2M SDE Karras|DPM\+\+ SDE Karras/.test(
          sampler
        )
      )
        sampler = "Euler a";
      if (!/\(none\)|Light|Standard|Heavy/.test(quality)) quality = "Heavy";
      if (
        !/Custom|640 x 1536|832 x 1216|1024 x 1024|1152 x 896|1344 x 768|768 x 1344|896 x 1152|1216 x 832|1536 x 640/.test(
          ratio
        )
      )
        ratio = "896 x 1152";
      if (quality === "Custom")
        async () => {
          if (!width || isNaN(width) || +width > 2048)
            return reject("Enter Valid Image Width Below 2048");
          if (!height || isNaN(height) || +height > 2048)
            return reject("Enter Valid Image Height Below 2048");
        };

      // ? Headers
      const headers = {
        origin: BASE_URL,
        referer: BASE_URL + "/?",
        "user-agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
        "content-type": "application/json",
      };

      // ? Token
      const { data: token } = await fetch(BASE_URL + "/run/predict", {
        method: "POST",
        headers,
        body: JSON.stringify({
          data: [0, true],
          event_data: null,
          fn_index: 4,
          session_hash,
          trigger_id: 6,
        }),
      }).then((v) => v.json());

      // ? Join
      await fetch(BASE_URL + "/queue/join?", {
        method: "POST",
        headers,
        body: JSON.stringify({
          data: [
            prompt,
            negative,
            token[0],
            width,
            height,
            7,
            28, // ? Step
            sampler, // ? Sampler
            ratio, // ? Aspect ratio
            style, // ? Style
            quality, // ? Quality
            false,
            0.55,
            1.5,
            true,
          ],
          event_data: null,
          fn_index: 5,
          session_hash,
          trigger_id: 7,
        }),
      }).then((v) => v.json());

      // ? Generate Images
      const stream = await fetch(
        BASE_URL + "/queue/data?" + new URLSearchParams({ session_hash })
      ).then((v) => v.body);

      // ? Handle Stream
      stream.on("data", (v) => {
        const data = JSON.parse(v.toString().split("data: ")[1]);
        if (data.msg !== "process_completed") return;
        if (!data.success) return reject("Image Generation Failed!");
        return resolve(data.output.data[0]);
      });
    } catch (e) {
      reject(e);
    }
  });
}
async function omniplexAi(
  prompt,
  system = "You are an Ai Asistant that is destinated to help user with their problems"
) {
  return new Promise(async (resolve, reject) => {
    try {
      const BASE_URL = "https://omniplex.ai/api";
      const headers = {
        origin: BASE_URL.replace("/api", ""),
        "user-agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
        "Content-Type": "application/json",
      };
      const chatJSON = {
        frequency_penalty: 0,
        max_tokens: 512,
        messages: [
          {
            role: "system",
            content: system,
          },
          {
            role: "user",
            content: prompt,
          },
        ],
        model: "gpt-3.5-turbo",
        presence_penalty: 0,
        temperature: 1,
        top_p: 1,
      };

      // ? Determine which mode
      const { mode, arg } = await fetch(BASE_URL + "/tools", {
        method: "POST",
        headers,
        body: JSON.stringify(chatJSON.messages),
      }).then((v) => v.json());

      // ? Run by mode type
      switch (mode) {
        case "search": {
          const a = await searchMode();
          if (!a[0]) reject("Search mode failed with error : \n" + a[1] || a);
          return resolve({
            mode,
            data: a[0],
            search: a[1],
          });
          break;
        }

        case "chat": {
          const b = await chat();
          if (!b[0]) reject("Chat mode failed with error : \n" + b[1] || b);
          return resolve({
            mode,
            data: b,
          });
          break;
        }
      }

      // ? Handler
      async function chat() {
        return new Promise(async (s, r) => {
          try {
            const a = await fetch(BASE_URL + "/chat", {
              method: "POST",
              headers,
              body: JSON.stringify(chatJSON),
            }).then((v) => v.text());

            if (!a) return r([false, "Failed to get result"]);
            s(a);
          } catch (e) {
            r(e);
          }
        });
      }

      async function searchMode() {
        return new Promise(async (s, r) => {
          try {
            const a = await fetch(
              BASE_URL +
                "/search?" +
                new URLSearchParams({
                  q: "search" + prompt,
                  limit: 5,
                })
            ).then((v) => v.json());

            if (a.message !== "Success") return r([false, "Failed to search"]);

            const b = a.data.webPages.value.map((v) => v.url);
            const c = await fetch(
              BASE_URL +
                "/scrape?" +
                new URLSearchParams({
                  urls: b.join(","),
                }),
              {
                method: "POST",
                headers,
              }
            ).then((v) => v.text());
            chatJSON.messages[1].content = c + "\n\nQuestion : " + prompt;
            chatJSON.messages[0].content = `Generate a comprehensive and informative answer (but no more than 256 words in 2 paragraphs) for a given question solely based on the provided web Search Results (URL and Summary).You must only use information from the provided search results.Use an unbiased and journalistic tone.Use this current date and time: ${new Date().toUTCString()}.Combine search results together into a coherent answer.Do not repeat text.Only cite the most relevant results that answer the question accurately.If different results refer to different entities with the same name, write separate answers for each entity.You have the ability to search and will be given websites and the scarped data from them and you will have to make up an answer with that only. ${system}`;
            const d = await fetch(BASE_URL + "/chat", {
              method: "POST",
              headers,
              body: JSON.stringify(chatJSON),
            }).then((v) => v.text());
            s([d, a.data]);
          } catch (e) {
            // r(e);
          }
        });
      }
    } catch (e) {
      reject([false, e]);
    }
  });
}
async function ChatEqing(content) {
  try {
    const formattedDate = new Date().toLocaleString("id-ID", {
      day: "numeric",
      month: "numeric",
      year: "numeric",
      hour: "numeric",
      minute: "numeric",
      second: "numeric",
      hour12: false
    }).replace(/:/g, ".");
    const response = await fetch("https://chat.eqing.tech/api/openai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-requested-with": "XMLHttpRequest",
        "x-guest-id": "jwR1jqSQNUaVihChLqQmk",
        useSearch: "false",
        plugins: "0",
        accept: "text/event-stream",
        "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Mobile Safari/537.36",
        Referer: "https://chat.eqing.tech/#/chat"
      },
      body: JSON.stringify({
        messages: [{
          role: "system",
          content: `\nCurrent model: gpt-4o-mini\nCurrent time: ${formattedDate}\nLatex inline: $ x^2 $ \nLatex block: $$ e=mc^2 $$\n\n`
        }, {
          role: "user",
          content: content
        }],
        stream: true,
        model: "gpt-4o-mini",
        temperature: .5,
        presence_penalty: 0,
        frequency_penalty: 0,
        top_p: 1,
        chat_token: 63,
        captchaToken: "P1_eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.hadwYXNza2V5xQUZkY1Z98HAIuwgz9AZTo6KUEVGWSNm-7Pu-YPONk9QTTEUkSbxUG63epLUjmhFjBxgKugqfrV0TN_2Vet9iKiqVbCnh6F1oWgqlxjCEyXMIqBw2Ay6r1B8ZEl34s56IZRokGYU6f8C7YZzT5SJkFIvinFbyGgPp24Q71tDj30WiOYs_XHbPqn8PwF-dxcgGgjSmC2Vm6HII9Axnd53ySLDhakLDV5l9V5qjd-pV9t1qXpcjWOS0FEM78MQBQE19pQExamhG0Nga4E1o7Ic5KkIgEfiYzBuxhVWcAqj14WEHFK-R1CRs8qWob6Pi3XvmvGQtJ7EgynPB5FM9bOSUabusKV7_FV9YBXS0bz6HGNKQiYTQa4bVSepMq3nwdtMOFKhdQH8V5cwyaJXqgUNyO8qdJ12x-5PKPqIKNuaXb3dXAk3gs2jzA0MjVBgi7VyBOed1bRTWy-KPNtZoCDFP56bRfbUVgaNpjFGXtXNhPYYXvlYXRcoIgQj2aZSDrU1qJ2nLKEtAOGI4ZqMIIQ61HVYcd5EN703vGGxaSghurdnal8X7BDO-r93yKTj3RucLk4W1y6Sqgwy-UktHhOf4NIXBn4TJ-LzIxCTp9yiSZiaxTPhysCp2IVIjJH9kFswIY-dNRhXgdDNjaVdegLaCjOqRKLzvUpYfjiAIGHBwYRH1xk5CythyBGDnAEHRQUt8_YixAnaTeQWeaPamXT2k8Q3httenqhzT3XTv7uCqe61KfgDE95oJSUOU0u2JjFuBB76NBhkwVAW5UDtJROE0Duydj4fFj-UookNGQ_f_sgEog8P1fcspkPAP8OappJ3WGkIaWDJIzcG8ObaT4awfNwyiEM-rsJCJrUyz6Yk1tMZLcoFCQ0pS28oH4MateWjtyZDxL8uads3qQyqoSgBXscqIcQKN2Tzqj7cqPyxTFvdJD1yADgX3HpcpOqTvQ5EzkQ4Zh_prcEID2gVnH8VMR_4BukZqS-E076VM15Id-9INMDJFaoDk6x2WhtOtJe7ob7osinjzVVGtaZ8sNDJxlEnzwxSt9QOdVQCa-8iCMVrxd85jXXGYVQEbruDFjrP-8LZ_gaDg1kdoPT0ddxfwM_vGW_wsmbX-k869C_C0UBwa5U1yK8wTSpOMi52BfnbgkZHyLdTvDmJRRHvkiL3v50Rz_436ejH8UU_ASFaV8wysM4bP21TOG9k0MahgJJYuHCxhh_hPxbSvEV7Qixlepd6wAjx4Gi2sLVztFF2d7sf7KvqDJMtcmO8Et6oTn16FTdDLRkNvIFn7W3Y89vz-23iWtQQxvihbqzFOc5xDgt2u-dxUoZKPJtQD-kKKpCW75B5K-XgInwtx1Ob9y8dAP6O8yGmvm4qKZjuNYi0jNzstYJvlckfwDFJVyhoCpJaLwj1HW7D4qZLTlWH9-taFvtm-6fF3dwIc5MgNXner5dnZGSRAYCHTF4GMnwXWaKJfDKnqrJRszMxBuJMkxKlL2BXkrHQYOKI0i5rENI4l9VE5aAz15kBAeiHifS_SGa17CjlNGhiSarpviK19vIT1wA3B6187rhhlMP_oHraJ1dIqyef_pzJ7P7BDp2dGtGj8SNoRau6YHrfQhjduJcBTIbxznJITy6D83JEGUS-I7lF_KdnE6-biPmGYyrpJupi6GmfCp6qlsPb6lTXjfRbrCC0WEz5BlAEtFCb7rTVTfLfPZHWawPF54rexO0mSSmT7aubiGGkpbtf6NTgo2V4cM5mzc-eqHNoYXJkX2lkzg9y6m-ia3KoMTQ5MDJjY2aicGQA.V55IkMN8HlHCsFaBMmu39k9KiKRb5Djj9E1R7mGan5s"
      }),
      compress: true
    });
    const result = await response.text();
    return result.split("\n\n").filter(data => data.includes('data: {"id":"chatcmpl')).slice(0, -52).map(data => {
      try {
        return JSON.parse(data.match(/{.*}/)?.[0]);
      } catch (error) {
        return console.error("Error parsing JSON:", error), null;
      }
    }).filter(Boolean).map(data => data.choices[0]?.delta.content).join("");
  } catch (error) {
    console.error("Error:", error);
    return null;
  }
}
const generateUid = () => crypto.randomUUID();
async function Leingpt(content, conversationId) {
  try {
    const response = await fetch("https://leingpt.ru/backend-api/v2/conversation", {
      method: "POST",
      headers: {
        Accept: "text/event-stream",
        "Content-Type": "application/json",
        "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Mobile Safari/537.36",
        Referer: "https://leingpt.ru/chat/"
      },
      body: JSON.stringify({
        conversation_id: conversationId,
        action: "_ask",
        model: "gemini-1.5-pro-exp-0801",
        jailbreak: "Обычный",
        tonegpt: "Balanced",
        streamgen: false,
        web_search: false,
        rolej: "default",
        meta: {
          id: parseInt(conversationId),
          content: {
            conversation: [],
            content_type: "text",
            parts: [{
              content: content,
              role: "user"
            }]
          }
        }
      }),
      compress: true
    });
    const data = await response.text();
    return data || "No answer received.";
  } catch (error) {
    console.error("Error:", error);
    return "Terjadi kesalahan saat memproses permintaan.";
  }
}
module.exports = {
  LetmeGpt,
  leptonAi,
  Simsimi,
  GoodyAI,
  CgtAi,
  thinkany,
  degreeguru,
  ragbot,
  stoicai,
  stoicgpt,
  detectText,
  Gemini,
  omniplexAi,
  stableDiff, 
  animagine,
  BoredHumans,
  ChatEqing,
  Leingpt
};
