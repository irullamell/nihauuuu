const fetch = require('node-fetch');
const FormData = require('form-data');
const { fromBuffer } = require('file-type');

/**
 * Upload image to telegra.ph
 * Supported mimetype:
 * - `image/jpeg`
 * - `image/jpg`
 * - `image/png`
 * @param {Buffer} buffer Image Buffer
 */
const uploadImage = async buffer => {
try {
const { ext } = await fromBuffer(buffer);
let form = new FormData();
form.append('file', buffer, 'tmp.' + ext);
const response = await fetch("https://cdn.meitang.xyz/upload", {
method: "POST",
body: form,
});

const data = await response.json();
if (!response.ok) return {
status: false,
message: new Error(data.error || 'Failed to upload file')
}

return {
status: true,
url: data.file.url
}
} catch (error) {
return {
status: false,
msg: String(error)
}
}
}

exports.run = {
usage: ['setcover'],
hidden: ['cover'],
use: 'reply photo',
category: 'owner',
async: async (m, { func, mecha, setting, quoted }) => {
if (!/image/.test(quoted.mime)) return m.reply('Image not found.')
let buffer = await quoted.download()
let data = await uploadImage(buffer)
if (!data.status) return m.reply(data.message)
setting.cover = data.url;
mecha.reply(m.chat, func.texted('bold', 'Cover successfully set.'), m)
},
owner: true
}