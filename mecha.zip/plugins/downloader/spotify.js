const axios = require('axios'),
fetch = require('node-fetch');

exports.run = {
usage: ['spotify', 'spotifydl'],
use: 'parameter',
category: 'downloader',
async: async (m, { func, mecha }) => {
switch (m.command) {
case 'spotify':{
if (!m.text) return m.reply(func.example(m.cmd, 'terlambat untuk berdusta'))   
mecha.sendReact(m.chat, '🕒', m.key)
const result = await searchSpotify(m.text);
if (result.length == 0) return m.reply('Data empty.')
let rows = [];
let title = '```Result from:```' + ' `' + m.text + '`'
result.forEach((track, index) => {
rows.push({
title: `${index + 1}. ${track.name} - ${track.artists}`,
description: `- Duration : ${track.duration}\n- Popularity : ${track.popularity}`,
id: `${m.prefix}spotifydl ${track.link}`
})
})
let sections = [{
title: 'S P O T I F Y - S E A R C H',
rows: rows
}]
let buttons = [
['list', 'Click Here ⎙', sections],
]
mecha.sendButton(m.chat, title, 'select the list button below.', 'Powered by : https://api.spotify.com', buttons, m, {
expiration: m.expiration
})
}
break
case 'spotifydl':{
if (!m.text) return m.reply(`Usage: ${m.cmd} url\n\nExample: *${m.cmd} https://open.spotify.com/track/4O6k4SPSTBvohXJcaeZd46*`)
if (!m.args[0].includes('open.spotify.com/track')) return m.reply(global.mess.error.url)
mecha.sendReact(m.chat, '🕒', m.key)
await spotifydl(m.args[0]).then(async (res) => {
let txt = `*S P O T I F Y - D O W N L O A D E R*\n`
txt += `\n◦ Title: ${res.title}`
txt += `\n◦ Duration: ${res.duration}`
txt += `\n◦ Artist: ${res.artist}`
txt += `\n\n_Please wait audio is being sent..._`
mecha.sendMessageModify(m.chat, txt, m, {
title: 'SPOTIFY DOWNLOADER',
body: global.header, 
thumbnail: await (await fetch(res.image)).buffer(),
largeThumb: true
}).then(q => mecha.sendMessage(m.chat, {audio: {url: res.download}, mimetype: 'audio/mpeg'}, {quoted: q, ephemeralExpiration: m.expiration}))
})
}
break
}
},
premium: true,
limit: true
}

async function spotifydl(url) {
return new Promise(async (resolve, reject) => {
try {
const data = await axios.get(`https://api.fabdl.com/spotify/get?url=${encodeURIComponent(url)}`, {
headers: {
accept: "application/json, text/plain, */*",
"accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
"sec-ch-ua": "\"Not)A;Brand\";v=\"24\", \"Chromium\";v=\"116\"",
"sec-ch-ua-mobile": "?1",
"sec-ch-ua-platform": "\"Android\"",
"sec-fetch-dest": "empty",
"sec-fetch-mode": "cors",
"sec-fetch-site": "cross-site",
Referer: "https://spotifydownload.org/",
"Referrer-Policy": "strict-origin-when-cross-origin",
},
}
);
const res = await axios.get(`https://api.fabdl.com/spotify/mp3-convert-task/${data.data.result.gid}/${data.data.result.id}`, {
headers: {
accept: "application/json, text/plain, */*",
"accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
"sec-ch-ua": "\"Not)A;Brand\";v=\"24\", \"Chromium\";v=\"116\"",
"sec-ch-ua-mobile": "?1",
"sec-ch-ua-platform": "\"Android\"",
"sec-fetch-dest": "empty",
"sec-fetch-mode": "cors",
"sec-fetch-site": "cross-site",
Referer: "https://spotifydownload.org/",
"Referrer-Policy": "strict-origin-when-cross-origin",
},
}
);
const result = {
creator: 'SuryaDev.',
title: data.data.result.name,
type: data.data.result.type,
artist: data.data.result.artists,
duration: convert(data.data.result.duration_ms),
image: data.data.result.image,
download: 'https://api.fabdl.com' + res.data.result.download_url,
}
resolve(result);
} catch (error) {
reject(error);
}
});
};

async function searchSpotify(query) {
try {
const access_token = await getAccessToken();
const response = await axios.get(`https://api.spotify.com/v1/search?q=${query}&type=track&limit=10`, {
headers: {
Authorization: `Bearer ${access_token}`,
},
});
const data = response.data;
const tracks = data.tracks.items.map(item => ({
name: item.name,
artists: item.artists.map(artist => artist.name).join(', '),
popularity: item.popularity,
link: item.external_urls.spotify,
image: item.album.images[0].url,
duration: convert(item.duration_ms),
}));
return tracks;
} catch (error) {
console.error('Error searching Spotify:', error);
throw 'An error occurred while searching for songs on Spotify.';
}
}

async function getAccessToken() {
try {
const client_id = 'acc6302297e040aeb6e4ac1fbdfd62c3';
const client_secret = '0e8439a1280a43aba9a5bc0a16f3f009';
const basic = Buffer.from(`${client_id}:${client_secret}`).toString("base64");
const response = await axios.post('https://accounts.spotify.com/api/token', 'grant_type=client_credentials', {
headers: {
Authorization: `Basic ${basic}`,
'Content-Type': 'application/x-www-form-urlencoded',
},
});
const data = response.data;
return data.access_token;
} catch (error) {
console.error('Error getting Spotify access token:', error);
throw 'An error occurred while obtaining Spotify access token.';
}
}

function convert(ms) {
var minutes = Math.floor(ms / 60000)
var seconds = ((ms % 60000) / 1000).toFixed(0)
return minutes + ':' + (seconds < 10 ? '0' : '') + seconds
}